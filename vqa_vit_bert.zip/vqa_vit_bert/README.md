# Visual Question Answering (VQA) with Vision Transformer + BERT

This project implements a Visual Question Answering (VQA) system using a Vision Transformer (ViT) for image feature extraction and BERT for question encoding.

## Setup
1. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```

## Files
- `vqa_model.py`: Main model definition.
- `inference.py`: Script for running inference with images and questions.
- `train.py`: Script for training the model on a VQA dataset.
- `gui_demo.py`: Simple GUI for VQA demo.
- `utils.py`: Utility functions for dataset and answer vocab handling.
- `requirements.txt`: Python dependencies.

## Training
1. Prepare your VQA dataset as a JSON file (see `utils.py` for format) and place images in a directory.
2. Prepare an answer vocabulary JSON file (list of answer strings).
3. Update paths in `train.py` (`json_path`, `image_dir`, `answer_vocab_path`).
4. Run:
   ```bash
   python train.py
   ```
   The model will be saved as `vqa_vit_bert.pth`.

## Inference (Command Line)
1. Place your trained model and answer vocab in the project directory.
2. Run:
   ```bash
   python inference.py <image_path> "<question>"
   ```
   Example:
   ```bash
   python inference.py sample.jpg "What is the color of the cat?"
   ```

## Answer Generation (BLIP)
1. Install requirements (see above).
2. Run:
   ```bash
   python answer_generation.py <image_path> "<question>"
   ```
   Example:
   ```bash
   python answer_generation.py sample.jpg "What is the man holding?"
   ```
   This uses the BLIP model to generate free-form answers.

## ViT Attention Visualization
1. Install requirements (see above).
2. Run:
   ```bash
   python vit_attention_viz.py <image_path> [layer] [head]
   ```
   Example:
   ```bash
   python vit_attention_viz.py sample.jpg 0 0
   ```
   This will display the attention map for the specified ViT layer and head.

## GUI Demo
1. Place your trained model and answer vocab in the project directory.
2. Run:
   ```bash
   python gui_demo.py
   ```
   Use the GUI to select an image, enter a question, and get an answer.

## Notes
- For real use, train on a VQA dataset and use a real answer vocabulary.
- The provided scripts are templates; adapt for your dataset as needed.
