import PySimpleGUI as sg
from PIL import Image
import io
import torch
from transformers import BertTokenizer, ViTFeatureExtractor
from vqa_model import VQAViTBERT
from utils import load_answer_vocab, load_image

# Load model and assets
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
model = VQAViTBERT(num_answers=1000)
model.load_state_dict(torch.load('vqa_vit_bert.pth', map_location=device))
model.eval()
model.to(device)
tokenizer = BertTokenizer.from_pretrained('bert-base-uncased')
feature_extractor = ViTFeatureExtractor.from_pretrained('google/vit-base-patch16-224-in21k')
answer_vocab = load_answer_vocab('answer_vocab.json')

def predict(image_path, question):
    image = load_image(image_path)
    image_inputs = feature_extractor(images=image, return_tensors="pt").to(device)
    text_inputs = tokenizer(question, return_tensors="pt", padding=True, truncation=True).to(device)
    with torch.no_grad():
        logits = model(image_inputs['pixel_values'], text_inputs['input_ids'], text_inputs['attention_mask'])
        pred_idx = logits.argmax(dim=1).item()
        return answer_vocab[pred_idx]

layout = [
    [sg.Text('Image'), sg.Input(key='-IMAGE-'), sg.FileBrowse(), sg.Image(key='-PREVIEW-')],
    [sg.Text('Question'), sg.Input(key='-QUESTION-')],
    [sg.Button('Predict'), sg.Text('Answer:'), sg.Text('', key='-ANSWER-')]
]
window = sg.Window('VQA ViT+BERT Demo', layout)

while True:
    event, values = window.read()
    if event == sg.WIN_CLOSED:
        break
    if event == 'Predict':
        img_path = values['-IMAGE-']
        question = values['-QUESTION-']
        if img_path and question:
            answer = predict(img_path, question)
            window['-ANSWER-'].update(answer)
            # Show preview
            img = Image.open(img_path).resize((224,224))
            bio = io.BytesIO()
            img.save(bio, format="PNG")
            window['-PREVIEW-'].update(data=bio.getvalue())
window.close()
