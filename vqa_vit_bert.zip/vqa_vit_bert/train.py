import torch
from torch.utils.data import Dataset, DataLoader
from transformers import BertTokenizer, ViTFeatureExtractor
from vqa_model import VQAViTBERT
from utils import load_vqa_dataset, load_answer_vocab
import torch.nn.functional as F
import torch.optim as optim
import os

class VQADataset(Dataset):
    def __init__(self, data, tokenizer, feature_extractor, answer2idx):
        self.data = data
        self.tokenizer = tokenizer
        self.feature_extractor = feature_extractor
        self.answer2idx = answer2idx

    def __len__(self):
        return len(self.data)

    def __getitem__(self, idx):
        sample = self.data[idx]
        image = self.feature_extractor(images=sample['image'], return_tensors="pt")['pixel_values'].squeeze(0)
        text = self.tokenizer(sample['question'], return_tensors="pt", padding='max_length', truncation=True, max_length=32)
        answer = self.answer2idx.get(sample['answer'], 0)
        return image, text['input_ids'].squeeze(0), text['attention_mask'].squeeze(0), torch.tensor(answer)

def train_vqa(model, dataloader, optimizer, device):
    model.train()
    total_loss = 0
    for image, input_ids, attention_mask, answer in dataloader:
        image = image.to(device)
        input_ids = input_ids.to(device)
        attention_mask = attention_mask.to(device)
        answer = answer.to(device)
        optimizer.zero_grad()
        logits = model(image, input_ids, attention_mask)
        loss = F.cross_entropy(logits, answer)
        loss.backward()
        optimizer.step()
        total_loss += loss.item()
    return total_loss / len(dataloader)

def main():
    # Paths to your data
    json_path = 'train_data.json'  # You must provide this
    image_dir = 'images'           # You must provide this
    answer_vocab_path = 'answer_vocab.json'  # You must provide this

    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    tokenizer = BertTokenizer.from_pretrained('bert-base-uncased')
    feature_extractor = ViTFeatureExtractor.from_pretrained('google/vit-base-patch16-224-in21k')
    answer_vocab = load_answer_vocab(answer_vocab_path)
    answer2idx = {a: i for i, a in enumerate(answer_vocab)}
    data = load_vqa_dataset(json_path, image_dir)
    dataset = VQADataset(data, tokenizer, feature_extractor, answer2idx)
    dataloader = DataLoader(dataset, batch_size=4, shuffle=True)
    model = VQAViTBERT(num_answers=len(answer_vocab)).to(device)
    optimizer = optim.AdamW(model.parameters(), lr=2e-5)
    epochs = 3
    for epoch in range(epochs):
        loss = train_vqa(model, dataloader, optimizer, device)
        print(f"Epoch {epoch+1}/{epochs} - Loss: {loss:.4f}")
    torch.save(model.state_dict(), 'vqa_vit_bert.pth')

if __name__ == "__main__":
    main()
