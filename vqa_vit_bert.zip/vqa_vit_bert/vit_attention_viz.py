import torch
import matplotlib.pyplot as plt
from transformers import ViTModel, ViTFeatureExtractor
from PIL import Image
import numpy as np
import sys

def show_attention(image_path, layer=0, head=0):
    model = ViTModel.from_pretrained('google/vit-base-patch16-224-in21k', output_attentions=True)
    feature_extractor = ViTFeatureExtractor.from_pretrained('google/vit-base-patch16-224-in21k')
    image = Image.open(image_path).convert('RGB')
    inputs = feature_extractor(images=image, return_tensors="pt")
    outputs = model(**inputs)
    attn = outputs.attentions[layer][0, head]  # (num_tokens, num_tokens)
    # CLS token attends to patches
    cls_attn = attn[0, 1:].detach().numpy()
    # Reshape to 14x14 for base ViT
    size = int(np.sqrt(cls_attn.shape[0]))
    cls_attn_map = cls_attn.reshape(size, size)
    # Show attention map over image
    plt.figure(figsize=(8,4))
    plt.subplot(1,2,1)
    plt.imshow(image.resize((224,224)))
    plt.axis('off')
    plt.subplot(1,2,2)
    plt.imshow(image.resize((224,224)))
    plt.imshow(cls_attn_map, cmap='jet', alpha=0.5, extent=(0,224,224,0))
    plt.axis('off')
    plt.title(f'ViT Attention (Layer {layer}, Head {head})')
    plt.show()

if __name__ == "__main__":
    img_path = sys.argv[1]
    layer = int(sys.argv[2]) if len(sys.argv) > 2 else 0
    head = int(sys.argv[3]) if len(sys.argv) > 3 else 0
    show_attention(img_path, layer, head)
