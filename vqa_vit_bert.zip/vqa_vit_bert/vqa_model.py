import torch
import torch.nn as nn
from transformers import BertModel, ViTModel

class VQAViTBERT(nn.Module):
    def __init__(self, num_answers=1000):
        super(VQAViTBERT, self).__init__()
        self.vision_encoder = ViTModel.from_pretrained('google/vit-base-patch16-224-in21k')
        self.text_encoder = BertModel.from_pretrained('bert-base-uncased')
        
        # Feature dimensions
        vision_dim = self.vision_encoder.config.hidden_size
        text_dim = self.text_encoder.config.hidden_size
        
        # Fusion and classification
        self.fusion = nn.Linear(vision_dim + text_dim, 512)
        self.classifier = nn.Linear(512, num_answers)
        self.relu = nn.ReLU()
        self.dropout = nn.Dropout(0.1)

    def forward(self, image, input_ids, attention_mask):
        vision_out = self.vision_encoder(pixel_values=image).last_hidden_state[:, 0]
        text_out = self.text_encoder(input_ids=input_ids, attention_mask=attention_mask).pooler_output
        
        combined = torch.cat([vision_out, text_out], dim=1)
        fused = self.relu(self.fusion(combined))
        fused = self.dropout(fused)
        logits = self.classifier(fused)
        return logits
