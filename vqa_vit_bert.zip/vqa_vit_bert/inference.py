import torch
from transformers import BertTokenizer, ViTFeatureExtractor
from PIL import Image
import sys
from vqa_model import VQAViTBERT

# Load models and tokenizers
model = VQAViTBERT(num_answers=1000)
model.eval()
tokenizer = BertTokenizer.from_pretrained('bert-base-uncased')
feature_extractor = ViTFeatureExtractor.from_pretrained('google/vit-base-patch16-224-in21k')

# Dummy answer list (replace with actual answer vocab for real use)
answer_list = [f"answer_{i}" for i in range(1000)]

def predict(image_path, question):
    image = Image.open(image_path).convert('RGB')
    image_inputs = feature_extractor(images=image, return_tensors="pt")
    text_inputs = tokenizer(question, return_tensors="pt", padding=True, truncation=True)
    
    with torch.no_grad():
        logits = model(image_inputs['pixel_values'], text_inputs['input_ids'], text_inputs['attention_mask'])
        pred_idx = logits.argmax(dim=1).item()
        return answer_list[pred_idx]

if __name__ == "__main__":
    img_path = sys.argv[1]
    question = sys.argv[2]
    answer = predict(img_path, question)
    print(f"Q: {question}\nA: {answer}")
