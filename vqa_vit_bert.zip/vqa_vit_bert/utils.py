import json
import os
from PIL import Image

def load_answer_vocab(path):
    with open(path, 'r') as f:
        return json.load(f)

def save_answer_vocab(vocab, path):
    with open(path, 'w') as f:
        json.dump(vocab, f)

def load_image(image_path):
    return Image.open(image_path).convert('RGB')

# Example for VQA v2 dataset loader (simplified)
def load_vqa_dataset(json_path, image_dir):
    with open(json_path, 'r') as f:
        data = json.load(f)
    samples = []
    for entry in data:
        img_path = os.path.join(image_dir, entry['image'])
        question = entry['question']
        answer = entry.get('answer', None)
        samples.append({'image': img_path, 'question': question, 'answer': answer})
    return samples
