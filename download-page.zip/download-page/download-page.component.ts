import { Component } from '@angular/core';
import { DataService } from './dataservice';
import * as JSZip from 'jszip';
import { saveAs } from 'file-saver';

@Component({
  selector: 'app-download-page',
  templateUrl: './download-page.component.html',
  styleUrls: ['./download-page.component.css']
})
export class DownloadPageComponent {
  domainName: string = '';
  moduleName?: string; // Optional field
  userStories: boolean = false;
  testCases: boolean = false;
  defects: boolean = false;
  all: boolean = false;

  constructor(private dataService: DataService) {}

  isCheckboxSelected(): boolean {
    return this.userStories || this.testCases || this.defects || this.all;
  }

  async submitForm() {
    if (!this.domainName.trim()) {
      alert('Please enter a domain name.');
      return;
    }

    if (!this.isCheckboxSelected()) {
      alert('Please select at least one checkbox.');
      return;
    }

    const formData: any = {
      domain: this.domainName,
      userStories: this.userStories,
      testCases: this.testCases,
      defects: this.defects
    };

    if (this.moduleName) {
      formData.module = this.moduleName;
    }

    try {
      // Create a zip file and add files based on selections
      const zip = new JSZip();
      const zipFilename = `${this.domainName}_data.zip`;

      // Function to add file to ZIP
      const addFileToZip = async (filename: string, data: any) => {
        const response = await this.dataService.getZipData(data).toPromise();
        zip.file(filename, response);
      };

      // Add files based on selections
      if (this.all || this.userStories) {
        await addFileToZip('userStories.json', { ...formData, userStories: true });
      }

      if (this.all || this.testCases) {
        await addFileToZip('testCases.json', { ...formData, testCases: true });
      }

      if (this.all || this.defects) {
        await addFileToZip('defects.json', { ...formData, defects: true });
      }

      const zipBlob = await zip.generateAsync({ type: 'blob' });
      saveAs(zipBlob, zipFilename);

      alert('Your files have been downloaded successfully.');
    } catch (error) {
      console.error('Download error:', error);
      alert('There was an error downloading the files.');
    }
  }

  onCheckboxChange(event: any) {
    const checkbox = event.target as HTMLInputElement;

    switch (checkbox.id) {
      case 'userStories':
        this.userStories = checkbox.checked;
        this.testCases = false;
        this.defects = false;
        break;
      case 'testCases':
        this.testCases = checkbox.checked;
        this.userStories = false;
        this.defects = false;
        break;
      case 'defects':
        this.defects = checkbox.checked;
        this.userStories = false;
        this.testCases = false;
        break;
      case 'all':
        this.all = checkbox.checked;
        if (this.all) {
          this.userStories = true;
          this.testCases = true;
          this.defects = true;
        } else {
          this.userStories = false;
          this.testCases = false;
          this.defects = false;
        }
        break;
    }
  }
}
