import { TestBed } from '@angular/core/testing';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { DataService } from './dataservice';


describe('DataService', () => {
  let service: DataService;
  let httpMock: HttpTestingController;
  const apiUrl = 'http://10.120.100.98:9999/download';

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [DataService]
    });

    // Get the service and HttpTestingController instances
    service = TestBed.get(DataService);
    httpMock = TestBed.get(HttpTestingController);
  });

  afterEach(() => {
    // Ensure no outstanding requests are pending
    httpMock.verify();
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should fetch data from the API using GET request', () => {
    const mockData = { domain: 'E-Commerce', 'user-stories': true, 'test-cases': true, 'defect-cases': false };

    // service.getData().subscribe(data => {
    //   expect(data).toEqual(mockData);
    // });

    // Expect a single GET request to the API URL
    const req = httpMock.expectOne(apiUrl);
    expect(req.request.method).toBe('GET');
    req.flush(mockData); // Respond with mock data
  });
});

