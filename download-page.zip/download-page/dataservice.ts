import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class DataService {
  private apiUrl = 'http://10.120.100.98:9999/download'; // Your API URL

  constructor(private http: HttpClient) {}

  // Method to post data to API and get ZIP file as a Blob
  getZipData(requestData: any): Observable<Blob> {
    // Define headers to accept blob response
    const headers = new HttpHeaders({
      'Accept': 'application/zip',
      'Content-Type': 'application/json'
    });

    return this.http.post<Blob>(this.apiUrl, requestData, { headers, responseType: 'blob' as 'json' })
      .pipe(
        catchError(error => {
          console.error('Download error:', error);
          return throwError(() => new Error('Download failed'));
        })
      );
  }
}
