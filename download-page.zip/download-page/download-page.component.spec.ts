import { ComponentFixture, TestBed } from '@angular/core/testing';
import { FormsModule } from '@angular/forms';
import { By } from '@angular/platform-browser';
import { DownloadPageComponent } from './download-page.component';

describe('DownloadPageComponent', () => {
  let component: DownloadPageComponent;
  let fixture: ComponentFixture<DownloadPageComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DownloadPageComponent ],
      imports: [ FormsModule ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DownloadPageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should generate JSON and trigger download on form submission', () => {
    // Set form values
    component.domainName = 'E-Commerce';
    component.userStories = true;
    component.testCases = true;
    component.defects = false;

    // Spy on document.createElement to test file download
    const createElementSpy = spyOn(document, 'createElement').and.callThrough();
    
    // Trigger form submission
    const form = fixture.debugElement.query(By.css('form'));
    form.triggerEventHandler('ngSubmit', null);

    fixture.detectChanges();

    // Assert that a Blob object was created
    expect(createElementSpy).toHaveBeenCalledWith('a');
    
    // Check that the download link is being created
    const anchor = createElementSpy.calls.mostRecent().returnValue;
    expect(anchor.download).toBe('data.json');
    expect(anchor.href).toContain('blob:');
  });
});
