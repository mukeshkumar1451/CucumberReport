-- MySQL dump 10.13  Distrib 8.0.41, for Win64 (x86_64)
--
-- Host: localhost    Database: ecommerce
-- ------------------------------------------------------
-- Server version	8.0.41

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `products`
--

DROP TABLE IF EXISTS `products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `products` (
  `product_id` bigint NOT NULL,
  `description` varchar(255) NOT NULL,
  `discount` double NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `price` double NOT NULL,
  `product_name` varchar(255) NOT NULL,
  `quantity` int DEFAULT NULL,
  `special_price` double NOT NULL,
  `category_id` bigint DEFAULT NULL,
  `seller_id` bigint DEFAULT NULL,
  PRIMARY KEY (`product_id`),
  KEY `FKog2rp4qthbtt2lfyhfo32lsw9` (`category_id`),
  KEY `FKbgw3lyxhsml3kfqnfr45o0vbj` (`seller_id`),
  CONSTRAINT `FKbgw3lyxhsml3kfqnfr45o0vbj` FOREIGN KEY (`seller_id`) REFERENCES `users` (`user_id`),
  CONSTRAINT `FKog2rp4qthbtt2lfyhfo32lsw9` FOREIGN KEY (`category_id`) REFERENCES `categories` (`category_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `products`
--

LOCK TABLES `products` WRITE;
/*!40000 ALTER TABLE `products` DISABLE KEYS */;
INSERT INTO `products` VALUES (1,'Experience the latest in mobile technology with advanced cameras, powerful processing, and an all-day battery.',10,'289f4b2e-70b7-4fb4-b889-51e527308aad.png',1450,'Iphone Xs max',90,1305,1,NULL),(2,'Ultra-thin laptop with Apple\'s M2 chip, providing fast performance in a lightweight, portable design.',20,'95b482c5-7844-4927-982e-37130a719fcd.png',2550,'MacBook Air M2s',40,2040,1,NULL),(52,'Experience the latest in Semi battery technology with advanced cameras, powerful processing, and an all-day battery.',10,'7deb19f8-642d-4e6e-ba8c-57bfc96add82.png',90,'Battery',86,81,2,NULL),(102,'Soft and breathable cotton t-shirt perfect for everyday wear, available in multiple colors.',15,'5dae41dd-202b-44be-8f5d-ea4785c63b9a.png',499,'Men\'s Cotton T-Shirt',146,424.15,3,NULL),(103,'Stylish and durable denim jacket with a modern fit, ideal for casual outings.',20,'8874022f-a299-475f-9187-8145852bd02f.png',1299,'Women\'s Denim Jacket',80,1039.2,3,NULL),(104,'Comfortable fleece-lined hoodie with adjustable drawstrings and a front pocket.',10,'7a67d075-39bc-4887-ae1d-96d41baf0d5c.png',999,'Unisex Hoodie',100,899.1,3,NULL),(105,'Elegant slim-fit trousers suitable for office wear and formal occasions.',18,'264d4f55-6c08-4330-bedc-50db90aecf37.png',1199,'Formal Trousers',60,983.1800000000001,3,NULL),(152,'Adorable and cozy pajama set made from soft cotton, perfect for a good night\'s sleep.',25,'dde33e4c-0510-46ad-b84d-5129da20bb82.png',699,'Kids\' Pajama Set',120,524.25,3,NULL),(153,'Compact and high-quality wireless earbuds with noise cancellation and long battery life.',15,'6617135d-a0df-476f-9464-c7abb91f6a7f.png',2499,'Wireless Earbuds',200,2124.15,2,NULL),(154,'Full HD Smart LED TV with built-in streaming apps and voice control support.',20,'8cd37ecc-8239-4932-9e82-d0bac718a3cf.png',24999,'Smart LED TV 43\"',50,19999.2,2,NULL),(155,'Portable Bluetooth speaker with deep bass, waterproof design, and 12-hour playtime.',10,'8dc1c0cd-b0e9-4f76-9b1b-8377365db78c.png',1999,'Bluetooth Speaker',120,1799.1,2,NULL),(156,'Latest smartphone with 128GB storage, triple camera setup, and fast charging support.',12,'22ae48a2-2a44-4a54-a2e5-12895cbccdb0.png',18999,'Smartphone - 128GB',75,16719.12,2,NULL),(157,'Powerful laptop with Intel i5 processor, 8GB RAM, and 512GB SSD for multitasking.',18,'d5d7973b-21a3-41e0-9356-3b9ac65334c7.png',45999,'Laptop - 15.6\" i5',40,37719.18,2,NULL),(158,'Eco-friendly, non-slip yoga mat with extra cushioning for comfort during workouts.',10,'23d6d743-fac8-406c-9a73-81e326926a45.png',899,'Yoga Mat',100,809.1,1,NULL),(159,'Space-saving adjustable dumbbells with quick weight change mechanism, ideal for home workouts.',15,'d9f4d0c0-fa8a-4ffb-bbad-f4952be02141.png',3499,'Adjustable Dumbbells',60,2974.15,1,NULL),(160,'Smart fitness band with heart rate monitor, step counter, and sleep tracking features.',12,'de6b2a79-760a-4bce-af6f-757d4b886c11.png',1999,'Fitness Tracker Band',150,1759.12,1,NULL),(161,'Set of 5 resistance bands with varying tension levels for strength training and rehabilitation.',20,'21e202b4-e727-4093-ba52-1629fbd7daf8.png',599,'Resistance Bands Set',200,479.2,1,NULL),(162,'Compact foldable treadmill with digital display, speed control, and shock absorption system.',18,'ea483a95-f9aa-416c-a869-9040ea06f3f6.png',24999,'Treadmill - Foldable',30,20499.18,1,NULL);
/*!40000 ALTER TABLE `products` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-06-13 11:56:03
