import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { MatDialog } from '@angular/material';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { PopupComponent } from './popup/popup.component';
import { DataService } from '../data.service';
@Component({
  selector: 'app-form-page',
  templateUrl: './form-page.component.html',
  styleUrls: ['./form-page.component.css']
})
export class FormPageComponent implements OnInit {
  formGroup: FormGroup
  domain = new FormControl();
  isDisabled = true
  enableDownloadTimeout: any
  obj = {
    domain: '',
    subdomain: '',
    moduleList: [],
    number_of_user_stories: '',
    number_of_test_cases: '',
    number_of_defects: ''
  }
  constructor(
    public dialog: MatDialog, private dataService: DataService
  ) {
    this.formGroup = new FormGroup(
      {
        Domain: new FormControl(),
        SubDomain: new FormControl(),
        Modules: new FormControl(),
        UserStories: new FormControl(),
        TestCases: new FormControl(),
        Defects: new FormControl()

      }
    )
  }

  ngOnInit() {
  }

  onSubmit() {
    console.log(this.formGroup.value);
    this.obj.domain = this.formGroup.value.Domain
    this.obj.subdomain = this.formGroup.value.SubDomain
    this.obj.moduleList = this.formGroup.value.Modules.split(",")
    this.obj.number_of_user_stories = this.formGroup.value.UserStories
    this.obj.number_of_test_cases = this.formGroup.value.TestCases
    this.obj.number_of_defects = this.formGroup.value.Defects
    console.log(this.obj)
    clearTimeout(this.enableDownloadTimeout);

    // Set timeout to enable download button after 10 minutes
    this.enableDownloadTimeout = setTimeout(() => {
      this.isDisabled = false;
    }, 600000);
    // const dialogRefRisk = this.dialog.open(PopupComponent, {
    //   width: '650px',
    //   data: { element: this.formGroup.value },
    // });

    this.dataService.postData(this.obj)
      .subscribe(response => {
        console.log('Response:', response);
        // Handle the response
      }, error => {
        console.error('Error:', error);
        // Handle the error
      });
  }
}
