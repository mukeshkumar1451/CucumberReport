import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-message-popup',
  templateUrl: './message-popup.component.html',
  styleUrls: ['./message-popup.component.css']
})
export class MessagePopupComponent implements OnInit {
  @Input() message: string = '';

  constructor() { }

  ngOnInit() {
  }


  closeModal() {
    // Implement logic to close the modal, e.g., using a service
  }

}
