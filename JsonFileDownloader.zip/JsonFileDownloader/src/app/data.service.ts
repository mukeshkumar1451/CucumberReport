import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class DataService {

  private baseUrl = 'http://10.120.100.98:9999';
  constructor(private http: HttpClient) { }
  postData(data): Observable<any> {
    return this.http.post(`${this.baseUrl}/generate-stories-test-artifacts`, data);
  }
}
