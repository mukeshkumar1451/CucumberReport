package com.ecommerce.project.modal;

public enum AppRole {
    ROLE_USER,
    ROLE_ADMIN,
    ROLE_SELLER
}
