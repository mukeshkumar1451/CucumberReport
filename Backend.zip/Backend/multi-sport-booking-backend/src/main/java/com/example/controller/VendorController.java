package com.example.controller;

import com.example.dto.BookingDTO;
import com.example.dto.SlotDTO;
import com.example.dto.VenueDTO;
import com.example.dto.VenueSportDTO;
import com.example.service.VendorService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import java.security.Principal;
import java.util.List;

import org.springframework.security.access.prepost.PreAuthorize;

@RestController
@RequestMapping("/api/vendor")
@PreAuthorize("hasRole('VENDOR')")
public class VendorController {
    @Autowired
    private VendorService vendorService;

    // Vendor dashboard: today's bookings, total earnings
    @GetMapping("/dashboard")
    public ResponseEntity<?> dashboard(Principal principal) {
        String email = principal.getName();
        double earnings = vendorService.getVendorEarnings(email);
        List<BookingDTO> bookings = vendorService.getVendorBookings(email);
        return ResponseEntity.ok(java.util.Map.of(
                "earnings", earnings,
                "bookings", bookings
        ));
    }

    // Create venue
    @PostMapping("/venues")
    public VenueDTO addVenue(@Valid @RequestBody VenueDTO venueDTO, Principal principal) {
        return vendorService.addVenue(venueDTO, principal.getName());
    }

    // Update venue
    @PutMapping("/venues/{venueId}")
    public VenueDTO updateVenue(@PathVariable Long venueId, @Valid @RequestBody VenueDTO venueDTO, Principal principal) {
        // Reuse addVenue logic for simplicity; in real app, implement update logic
        venueDTO.setId(venueId);
        return vendorService.addVenue(venueDTO, principal.getName());
    }

    // Delete venue
    @DeleteMapping("/venues/{venueId}")
    public ResponseEntity<?> deleteVenue(@PathVariable Long venueId, Principal principal) {
        // Not implemented: placeholder
        return ResponseEntity.status(501).body("Delete venue not implemented yet");
    }

    // Set discount for a venue sport
    @PutMapping("/venuesport/{id}/discount")
    public VenueSportDTO setDiscount(@PathVariable Long id, @RequestParam Integer thresholdHours, @RequestParam Double discountPercent, Principal principal) {
        return vendorService.setDiscount(id, thresholdHours, discountPercent, principal.getName());
    }

    // Add sport to venue
    @PostMapping("/sports")
    public VenueSportDTO addSportToVenue(@RequestParam Long venueId, @RequestParam Long sportId, @RequestParam Double pricePerHour, Principal principal) {
        return vendorService.addSportToVenue(venueId, sportId, pricePerHour, principal.getName());
    }

    // Create slot for venue sport
    @PostMapping("/slots")
    public SlotDTO addSlot(@RequestParam Long venueSportId, @Valid @RequestBody SlotDTO slotDTO, Principal principal) {
        return vendorService.addSlot(venueSportId, slotDTO, principal.getName());
    }

    // All bookings for vendor's venues
    @GetMapping("/bookings")
    public ResponseEntity<?> getVendorBookings(Principal principal,
                                               @RequestParam(defaultValue = "0") int page,
                                               @RequestParam(defaultValue = "10") int size) {
        List<BookingDTO> allBookings = vendorService.getVendorBookings(principal.getName());
        int start = Math.min(page * size, allBookings.size());
        int end = Math.min(start + size, allBookings.size());
        List<BookingDTO> paged = allBookings.subList(start, end);
        return ResponseEntity.ok(java.util.Map.of(
            "content", paged,
            "total", allBookings.size()
        ));
    }

    // Earnings summary
    @GetMapping("/earnings")
    public double getVendorEarnings(Principal principal) {
        return vendorService.getVendorEarnings(principal.getName());
    }
}
