package com.example.mapper;

import com.example.dto.SlotDTO;
import com.example.entity.Slot;

public class SlotMapper {
    public static SlotDTO toDTO(Slot slot) {
        if (slot == null) return null;
        SlotDTO dto = new SlotDTO();
        dto.setId(slot.getId());
        dto.setVenueSport(VenueSportMapper.toDTO(slot.getVenueSport()));
        dto.setDate(slot.getDate());
        dto.setStartTime(slot.getStartTime());
        dto.setEndTime(slot.getEndTime());
        dto.setStatus(slot.getStatus().name());
        return dto;
    }

    public static Slot toEntity(SlotDTO dto) {
        if (dto == null) return null;
        Slot slot = new Slot();
        slot.setId(dto.getId());
        slot.setVenueSport(VenueSportMapper.toEntity(dto.getVenueSport()));
        slot.setDate(dto.getDate());
        slot.setStartTime(dto.getStartTime());
        slot.setEndTime(dto.getEndTime());
        slot.setStatus(Slot.Status.valueOf(dto.getStatus()));
        return slot;
    }
}
