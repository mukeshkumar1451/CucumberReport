package com.example.dto;

import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class VenueSportDTO {
    private Long id;

    @NotNull
    private VenueDTO venue;
    @NotNull
    private SportDTO sport;
    @NotNull
    private Double pricePerHour;

    private Integer discountThresholdHours;
    private Double discountPercentage;
}
