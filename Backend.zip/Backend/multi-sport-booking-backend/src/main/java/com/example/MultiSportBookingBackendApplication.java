package com.example;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MultiSportBookingBackendApplication {
    public static void main(String[] args) {
        SpringApplication.run(MultiSportBookingBackendApplication.class, args);
    }

    @org.springframework.context.annotation.Bean
    public org.springframework.boot.CommandLineRunner dataLoader(
            com.example.repository.SportRepository sportRepository,
            com.example.repository.UserRepository userRepository,
            com.example.repository.VenueRepository venueRepository,
            com.example.repository.VenueSportRepository venueSportRepository,
            com.example.repository.SlotRepository slotRepository,
            org.springframework.security.crypto.password.PasswordEncoder passwordEncoder
    ) {
        return args -> {
            // Sample Sports
            var boxCricket = sportRepository.findAll().stream().filter(s -> s.getName().equals("Box Cricket")).findFirst().orElseGet(() -> sportRepository.save(com.example.entity.Sport.builder().name("Box Cricket").build()));
            var badminton = sportRepository.findAll().stream().filter(s -> s.getName().equals("Badminton")).findFirst().orElseGet(() -> sportRepository.save(com.example.entity.Sport.builder().name("Badminton").build()));
            var football = sportRepository.findAll().stream().filter(s -> s.getName().equals("Football")).findFirst().orElseGet(() -> sportRepository.save(com.example.entity.Sport.builder().name("Football").build()));

            // Sample Vendor
            var vendor = userRepository.findByEmail("vendor@example.com").orElseGet(() -> userRepository.save(com.example.entity.User.builder()
                    .name("Sample Vendor")
                    .email("vendor@example.com")
                    .phone("9999999999")
                    .passwordHash(passwordEncoder.encode("password"))
                    .roles(new java.util.HashSet<>(java.util.List.of(com.example.entity.User.Role.VENDOR)))
                    .build()));

            // Sample Venue
            var venue = venueRepository.save(com.example.entity.Venue.builder()
                    .vendor(vendor)
                    .name("Star Sports Arena")
                    .address("123 Main St")
                    .city("Metropolis")
                    .locationUrl("https://goo.gl/maps/example")
                    .contactNumber("8888888888")
                    .description("Best sports venue in town.")
                    .images("[\"img1.jpg\", \"img2.jpg\"]")
                    .status(com.example.entity.Venue.Status.ACTIVE)
                    .build());

            // Add sports to venue
            var venueSport1 = venueSportRepository.save(com.example.entity.VenueSport.builder()
                    .venue(venue)
                    .sport(boxCricket)
                    .pricePerHour(1200.0)
                    .build());
            var venueSport2 = venueSportRepository.save(com.example.entity.VenueSport.builder()
                    .venue(venue)
                    .sport(badminton)
                    .pricePerHour(800.0)
                    .build());

            // Add slots for today for Box Cricket
            java.time.LocalDate today = java.time.LocalDate.now();
            slotRepository.save(com.example.entity.Slot.builder()
                    .venueSport(venueSport1)
                    .date(today)
                    .startTime(java.time.LocalTime.of(9, 0))
                    .endTime(java.time.LocalTime.of(10, 0))
                    .status(com.example.entity.Slot.Status.AVAILABLE)
                    .build());
            slotRepository.save(com.example.entity.Slot.builder()
                    .venueSport(venueSport1)
                    .date(today)
                    .startTime(java.time.LocalTime.of(10, 0))
                    .endTime(java.time.LocalTime.of(11, 0))
                    .status(com.example.entity.Slot.Status.AVAILABLE)
                    .build());
            // Add slots for today for Badminton
            slotRepository.save(com.example.entity.Slot.builder()
                    .venueSport(venueSport2)
                    .date(today)
                    .startTime(java.time.LocalTime.of(11, 0))
                    .endTime(java.time.LocalTime.of(12, 0))
                    .status(com.example.entity.Slot.Status.AVAILABLE)
                    .build());
        };
    }
}
