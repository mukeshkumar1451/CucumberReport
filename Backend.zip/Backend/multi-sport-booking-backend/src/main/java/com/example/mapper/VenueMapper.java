package com.example.mapper;

import com.example.dto.VenueDTO;
import com.example.dto.UserDTO;
import com.example.entity.Venue;

public class VenueMapper {
    public static VenueDTO toDTO(Venue venue) {
        if (venue == null) return null;
        VenueDTO dto = new VenueDTO();
        dto.setId(venue.getId());
        dto.setVendor(UserMapper.toDTO(venue.getVendor()));
        dto.setName(venue.getName());
        dto.setAddress(venue.getAddress());
        dto.setCity(venue.getCity());
        dto.setLocationUrl(venue.getLocationUrl());
        dto.setContactNumber(venue.getContactNumber());
        dto.setDescription(venue.getDescription());
        dto.setImages(venue.getImages());
        dto.setStatus(venue.getStatus().name());
        return dto;
    }

    public static Venue toEntity(VenueDTO dto) {
        if (dto == null) return null;
        Venue venue = new Venue();
        venue.setId(dto.getId());
        venue.setVendor(UserMapper.toEntity(dto.getVendor()));
        venue.setName(dto.getName());
        venue.setAddress(dto.getAddress());
        venue.setCity(dto.getCity());
        venue.setLocationUrl(dto.getLocationUrl());
        venue.setContactNumber(dto.getContactNumber());
        venue.setDescription(dto.getDescription());
        venue.setImages(dto.getImages());
        venue.setStatus(Venue.Status.valueOf(dto.getStatus()));
        return venue;
    }
}
