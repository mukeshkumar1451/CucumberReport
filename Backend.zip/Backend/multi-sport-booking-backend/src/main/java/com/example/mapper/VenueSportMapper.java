package com.example.mapper;

import com.example.dto.VenueSportDTO;
import com.example.entity.VenueSport;

public class VenueSportMapper {
    public static VenueSportDTO toDTO(VenueSport venueSport) {
        if (venueSport == null) return null;
        VenueSportDTO dto = new VenueSportDTO();
        dto.setId(venueSport.getId());
        dto.setVenue(VenueMapper.toDTO(venueSport.getVenue()));
        dto.setSport(SportMapper.toDTO(venueSport.getSport()));
        dto.setPricePerHour(venueSport.getPricePerHour());
        dto.setDiscountThresholdHours(venueSport.getDiscountThresholdHours());
        dto.setDiscountPercentage(venueSport.getDiscountPercentage());
        return dto;
    }

    public static VenueSport toEntity(VenueSportDTO dto) {
        if (dto == null) return null;
        VenueSport venueSport = new VenueSport();
        venueSport.setId(dto.getId());
        venueSport.setVenue(VenueMapper.toEntity(dto.getVenue()));
        venueSport.setSport(SportMapper.toEntity(dto.getSport()));
        venueSport.setPricePerHour(dto.getPricePerHour());
        venueSport.setDiscountThresholdHours(dto.getDiscountThresholdHours());
        venueSport.setDiscountPercentage(dto.getDiscountPercentage());
        return venueSport;
    }
}
