package com.example.mapper;

import com.example.dto.ReviewDTO;
import com.example.entity.Review;

public class ReviewMapper {
    public static ReviewDTO toDTO(Review review) {
        if (review == null) return null;
        ReviewDTO dto = new ReviewDTO();
        dto.setId(review.getId());
        dto.setVenue(VenueMapper.toDTO(review.getVenue()));
        dto.setUser(UserMapper.toDTO(review.getUser()));
        dto.setRating(review.getRating());
        dto.setComment(review.getComment());
        return dto;
    }

    public static Review toEntity(ReviewDTO dto) {
        if (dto == null) return null;
        Review review = new Review();
        review.setId(dto.getId());
        review.setVenue(VenueMapper.toEntity(dto.getVenue()));
        review.setUser(UserMapper.toEntity(dto.getUser()));
        review.setRating(dto.getRating());
        review.setComment(dto.getComment());
        return review;
    }
}
