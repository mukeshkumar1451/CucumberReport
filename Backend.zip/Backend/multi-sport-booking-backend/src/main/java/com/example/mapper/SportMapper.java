package com.example.mapper;

import com.example.dto.SportDTO;
import com.example.entity.Sport;

public class SportMapper {
    public static SportDTO toDTO(Sport sport) {
        if (sport == null) return null;
        SportDTO dto = new SportDTO();
        dto.setId(sport.getId());
        dto.setName(sport.getName());
        return dto;
    }

    public static Sport toEntity(SportDTO dto) {
        if (dto == null) return null;
        Sport sport = new Sport();
        sport.setId(dto.getId());
        sport.setName(dto.getName());
        return sport;
    }
}
