package com.example.mapper;

import com.example.dto.UserDTO;
import com.example.entity.User;

public class UserMapper {
    public static UserDTO toDTO(User user) {
        if (user == null) return null;
        UserDTO dto = new UserDTO();
        dto.setId(user.getId());
        dto.setName(user.getName());
        dto.setEmail(user.getEmail());
        dto.setPhone(user.getPhone());
        java.util.Set<String> roleNames = new java.util.HashSet<>();
        if (user.getRoles() != null) {
            for (User.Role r : user.getRoles()) {
                roleNames.add(r.name());
            }
        }
        dto.setRoles(roleNames);
        return dto;
    }

    public static User toEntity(UserDTO dto) {
        if (dto == null) return null;
        User user = new User();
        user.setId(dto.getId());
        user.setName(dto.getName());
        user.setEmail(dto.getEmail());
        user.setPhone(dto.getPhone());
        java.util.Set<User.Role> roles = new java.util.HashSet<>();
        if (dto.getRoles() != null) {
            for (String r : dto.getRoles()) {
                roles.add(User.Role.valueOf(r));
            }
        }
        user.setRoles(roles);
        return user;
    }
}
