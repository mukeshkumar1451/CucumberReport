package com.example.controller;

import com.example.dto.UserDTO;
import com.example.entity.User;
import com.example.mapper.UserMapper;
import com.example.repository.UserRepository;
import com.example.security.JwtTokenProvider;
import jakarta.validation.Valid;
import lombok.Data;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

@RestController
@RequestMapping("/api/auth")
public class AuthController {
    @Autowired
    private UserRepository userRepository;
    @Autowired
    private PasswordEncoder passwordEncoder;
    @Autowired
    private AuthenticationManager authenticationManager;
    @Autowired
    private JwtTokenProvider jwtTokenProvider;

    @PostMapping("/register")
    public ResponseEntity<?> register(@Valid @RequestBody RegisterRequest request) {
        if (userRepository.findByEmail(request.getEmail()).isPresent()) {
            return ResponseEntity.badRequest().body("Email already in use");
        }
        if (request.getRoles() == null || request.getRoles().size() != 1) {
            throw new com.example.exception.ApiException("Exactly one role (USER or VENDOR) must be provided");
        }
        java.util.Set<User.Role> roles = new java.util.HashSet<>();
        for (String roleStr : request.getRoles()) {
            if (roleStr.equalsIgnoreCase("VENDOR")) {
                roles.add(User.Role.VENDOR);
            } else if (roleStr.equalsIgnoreCase("USER")) {
                roles.add(User.Role.USER);
            } else {
                throw new com.example.exception.ApiException("Invalid role: only USER or VENDOR allowed");
            }
        }
        User user = User.builder()
                .name(request.getName())
                .email(request.getEmail())
                .phone(request.getPhone())
                .passwordHash(passwordEncoder.encode(request.getPassword()))
                .roles(roles)
                .build();
        userRepository.save(user);
        return ResponseEntity.ok(UserMapper.toDTO(user));
    }

    @PostMapping("/login")
    public ResponseEntity<?> login(@Valid @RequestBody LoginRequest request) {
        Optional<User> userOpt = userRepository.findByEmail(request.getEmail());
        if (userOpt.isEmpty()) {
            return ResponseEntity.status(401).body("Invalid credentials");
        }
        Authentication authentication = authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(request.getEmail(), request.getPassword())
        );
        User user = userOpt.get();
        java.util.Set<String> roleNames = new java.util.HashSet<>();
        for (User.Role r : user.getRoles()) {
            roleNames.add(r.name());
        }
        String token = jwtTokenProvider.generateToken(user.getEmail(), roleNames);
        return ResponseEntity.ok(new JwtResponse(token, UserMapper.toDTO(user)));
    }

    @Data
    public static class RegisterRequest {
        @jakarta.validation.constraints.NotNull
        private String name;
        @jakarta.validation.constraints.Email
        private String email;
        @jakarta.validation.constraints.NotNull
        private String phone;
        @jakarta.validation.constraints.NotNull
        private String password;
        @jakarta.validation.constraints.NotNull
        private java.util.Set<String> roles; // e.g., ["USER", "VENDOR"]
    }

    @Data
    public static class LoginRequest {
        @jakarta.validation.constraints.Email
        private String email;
        @jakarta.validation.constraints.NotNull
        private String password;
    }

    @Data
    public static class JwtResponse {
        private final String token;
        private final UserDTO user;
    }
}
