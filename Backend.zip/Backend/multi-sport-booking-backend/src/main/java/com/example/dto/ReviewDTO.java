package com.example.dto;

import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class ReviewDTO {
    private Long id;
    @NotNull
    private VenueDTO venue;
    @NotNull
    private UserDTO user;
    @NotNull
    private Integer rating;
    private String comment;
}
