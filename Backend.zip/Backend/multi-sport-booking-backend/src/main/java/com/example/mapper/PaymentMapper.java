package com.example.mapper;

import com.example.dto.PaymentDTO;
import com.example.entity.Payment;

public class PaymentMapper {
    public static PaymentDTO toDTO(Payment payment) {
        if (payment == null) return null;
        PaymentDTO dto = new PaymentDTO();
        dto.setId(payment.getId());
        dto.setBooking(BookingMapper.toDTO(payment.getBooking()));
        dto.setAmount(payment.getAmount());
        dto.setPaymentGatewayId(payment.getPaymentGatewayId());
        dto.setStatus(payment.getStatus().name());
        return dto;
    }

    public static Payment toEntity(PaymentDTO dto) {
        if (dto == null) return null;
        Payment payment = new Payment();
        payment.setId(dto.getId());
        payment.setBooking(BookingMapper.toEntity(dto.getBooking()));
        payment.setAmount(dto.getAmount());
        payment.setPaymentGatewayId(dto.getPaymentGatewayId());
        payment.setStatus(Payment.Status.valueOf(dto.getStatus()));
        return payment;
    }
}
