package com.example.service;

import com.example.dto.UserDTO;
import com.example.dto.VenueDTO;
import com.example.entity.User;
import com.example.entity.Venue;
import com.example.mapper.UserMapper;
import com.example.mapper.VenueMapper;
import com.example.repository.BookingRepository;
import com.example.repository.UserRepository;
import com.example.repository.VenueRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class AdminService {
    @Autowired
    private UserRepository userRepository;
    @Autowired
    private VenueRepository venueRepository;
    @Autowired
    private BookingRepository bookingRepository;

    // Approve vendor (set role to VENDOR)
    @Transactional
    public UserDTO approveVendor(Long userId) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new com.example.exception.ResourceNotFoundException("User not found"));
        user.getRoles().add(User.Role.VENDOR);
        userRepository.save(user);
        return UserMapper.toDTO(user);
    }

    // Reject vendor (set role to USER)
    @Transactional
    public UserDTO rejectVendor(Long userId) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new com.example.exception.ResourceNotFoundException("User not found"));
        user.getRoles().clear();
        user.getRoles().add(User.Role.USER);
        userRepository.save(user);
        return UserMapper.toDTO(user);
    }

    // Manage all venues (list, update status)
    public List<VenueDTO> getAllVenues() {
        return venueRepository.findAll().stream().map(VenueMapper::toDTO).collect(Collectors.toList());
    }

    @Transactional
    public VenueDTO updateVenueStatus(Long venueId, String status) {
        Venue venue = venueRepository.findById(venueId)
                .orElseThrow(() -> new com.example.exception.ResourceNotFoundException("Venue not found"));
        venue.setStatus(Venue.Status.valueOf(status));
        venueRepository.save(venue);
        return VenueMapper.toDTO(venue);
    }

    // Platform analytics: total bookings and earnings
    public long getTotalBookings() {
        return bookingRepository.count();
    }

    public double getTotalEarnings() {
        return bookingRepository.findAll().stream()
                .filter(b -> b.getPaymentStatus() == com.example.entity.Booking.PaymentStatus.SUCCESS)
                .mapToDouble(com.example.entity.Booking::getTotalAmount)
                .sum();
    }
}
