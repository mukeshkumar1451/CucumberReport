package com.example.dto;

import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class PaymentDTO {
    private Long id;
    @NotNull
    private BookingDTO booking;
    @NotNull
    private Double amount;
    private String paymentGatewayId;
    @NotNull
    private String status;
}
