package com.example.mapper;

import com.example.dto.BookingDTO;
import com.example.entity.Booking;

public class BookingMapper {
    public static BookingDTO toDTO(Booking booking) {
        if (booking == null) return null;
        BookingDTO dto = new BookingDTO();
        dto.setId(booking.getId());
        dto.setUser(UserMapper.toDTO(booking.getUser()));
        dto.setSlot(SlotMapper.toDTO(booking.getSlot()));
        dto.setTotalAmount(booking.getTotalAmount());
        dto.setPaymentStatus(booking.getPaymentStatus().name());
        dto.setQrCode(booking.getQrCode());
        return dto;
    }

    public static Booking toEntity(BookingDTO dto) {
        if (dto == null) return null;
        Booking booking = new Booking();
        booking.setId(dto.getId());
        booking.setUser(UserMapper.toEntity(dto.getUser()));
        booking.setSlot(SlotMapper.toEntity(dto.getSlot()));
        booking.setTotalAmount(dto.getTotalAmount());
        booking.setPaymentStatus(Booking.PaymentStatus.valueOf(dto.getPaymentStatus()));
        booking.setQrCode(dto.getQrCode());
        return booking;
    }
}
