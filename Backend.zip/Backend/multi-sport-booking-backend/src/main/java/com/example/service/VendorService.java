package com.example.service;

import com.example.dto.*;
import com.example.entity.*;
import com.example.mapper.*;
import com.example.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.security.Principal;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class VendorService {
    @Autowired
    private UserRepository userRepository;
    @Autowired
    private VenueRepository venueRepository;
    @Autowired
    private SportRepository sportRepository;
    @Autowired
    private VenueSportRepository venueSportRepository;
    @Autowired
    private SlotRepository slotRepository;
    @Autowired
    private BookingRepository bookingRepository;
    @Autowired
    private PaymentRepository paymentRepository;

    // Add a new venue (Vendor only)
    @Transactional
    public VenueDTO addVenue(VenueDTO venueDTO, String vendorEmail) {
        User vendor = userRepository.findByEmail(vendorEmail)
                .orElseThrow(() -> new com.example.exception.UnauthorizedException("Vendor not found"));
        if (!vendor.getRoles().contains(User.Role.VENDOR)) {
            throw new com.example.exception.UnauthorizedException("Only vendors can add venues");
        }
        Venue venue = VenueMapper.toEntity(venueDTO);
        venue.setVendor(vendor);
        venue = venueRepository.save(venue);
        return VenueMapper.toDTO(venue);
    }

    // Set discount for a venue sport
    @Transactional
    public VenueSportDTO setDiscount(Long venueSportId, Integer thresholdHours, Double discountPercent, String vendorEmail) {
        VenueSport venueSport = venueSportRepository.findById(venueSportId)
                .orElseThrow(() -> new com.example.exception.ResourceNotFoundException("VenueSport not found"));
        if (!venueSport.getVenue().getVendor().getEmail().equals(vendorEmail)) {
            throw new com.example.exception.UnauthorizedException("Not your venue");
        }
        venueSport.setDiscountThresholdHours(thresholdHours);
        venueSport.setDiscountPercentage(discountPercent);
        venueSport = venueSportRepository.save(venueSport);
        return VenueSportMapper.toDTO(venueSport);
    }

    // Add sport to a venue
    @Transactional
    public VenueSportDTO addSportToVenue(Long venueId, Long sportId, Double pricePerHour, String vendorEmail) {
        Venue venue = venueRepository.findById(venueId)
                .orElseThrow(() -> new com.example.exception.ResourceNotFoundException("Venue not found"));
        if (!venue.getVendor().getEmail().equals(vendorEmail)) {
            throw new com.example.exception.UnauthorizedException("Not your venue");
        }
        Sport sport = sportRepository.findById(sportId)
                .orElseThrow(() -> new com.example.exception.ResourceNotFoundException("Sport not found"));
        VenueSport venueSport = VenueSport.builder()
                .venue(venue)
                .sport(sport)
                .pricePerHour(pricePerHour)
                .build();
        venueSport = venueSportRepository.save(venueSport);
        return VenueSportMapper.toDTO(venueSport);
    }

    // Add slot for a venue sport
    @Transactional
    public SlotDTO addSlot(Long venueSportId, SlotDTO slotDTO, String vendorEmail) {
        VenueSport venueSport = venueSportRepository.findById(venueSportId)
                .orElseThrow(() -> new com.example.exception.ResourceNotFoundException("VenueSport not found"));
        if (!venueSport.getVenue().getVendor().getEmail().equals(vendorEmail)) {
            throw new com.example.exception.UnauthorizedException("Not your venue");
        }
        Slot slot = SlotMapper.toEntity(slotDTO);
        slot.setVenueSport(venueSport);
        slot = slotRepository.save(slot);
        return SlotMapper.toDTO(slot);
    }

    // View vendor's own bookings
    public List<BookingDTO> getVendorBookings(String vendorEmail) {
        List<Booking> bookings = bookingRepository.findAll().stream()
                .filter(b -> b.getSlot().getVenueSport().getVenue().getVendor().getEmail().equals(vendorEmail))
                .collect(Collectors.toList());
        return bookings.stream().map(BookingMapper::toDTO).collect(Collectors.toList());
    }

    // View vendor's earnings
    public Double getVendorEarnings(String vendorEmail) {
        return bookingRepository.findAll().stream()
                .filter(b -> b.getSlot().getVenueSport().getVenue().getVendor().getEmail().equals(vendorEmail))
                .filter(b -> b.getPaymentStatus() == Booking.PaymentStatus.SUCCESS)
                .mapToDouble(Booking::getTotalAmount)
                .sum();
    }
}
