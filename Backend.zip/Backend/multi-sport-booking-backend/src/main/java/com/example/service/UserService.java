package com.example.service;

import com.example.dto.*;
import com.example.entity.*;
import com.example.mapper.*;
import com.example.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class UserService {
    @Autowired
    private VenueRepository venueRepository;
    @Autowired
    private SportRepository sportRepository;
    @Autowired
    private VenueSportRepository venueSportRepository;
    @Autowired
    private SlotRepository slotRepository;
    @Autowired
    private BookingRepository bookingRepository;
    @Autowired
    private UserRepository userRepository;
    @Autowired
    private ReviewRepository reviewRepository;

    // List all venues
    public List<VenueDTO> listAllVenues() {
        return venueRepository.findAll().stream().map(VenueMapper::toDTO).collect(Collectors.toList());
    }

    // View venue details
    public VenueDTO getVenueDetails(Long venueId) {
        return venueRepository.findById(venueId).map(VenueMapper::toDTO)
                .orElseThrow(() -> new com.example.exception.ResourceNotFoundException("Venue not found"));
    }

    // View sports for a venue
    public List<VenueSportDTO> getSportsForVenue(Long venueId) {
        return venueSportRepository.findAll().stream()
                .filter(vs -> vs.getVenue().getId().equals(venueId))
                .map(VenueSportMapper::toDTO)
                .collect(Collectors.toList());
    }

    // View slots by date for a sport
    public List<SlotDTO> getSlotsByDate(Long venueSportId, LocalDate date) {
        var slots = slotRepository.findAll().stream()
                .filter(slot -> slot.getVenueSport().getId().equals(venueSportId) && slot.getDate().equals(date))
                .map(SlotMapper::toDTO)
                .collect(Collectors.toList());
        if (slots.isEmpty()) {
            throw new com.example.exception.ResourceNotFoundException("No slots found for the given date and sport");
        }
        return slots;
    }

    // Book a slot (with availability check)
    @Transactional
    public BookingDTO bookSlot(Long slotId, String userEmail) {
        Slot slot = slotRepository.findById(slotId)
                .orElseThrow(() -> new com.example.exception.ResourceNotFoundException("Slot not found"));
        if (slot.getStatus() != Slot.Status.AVAILABLE) {
            throw new com.example.exception.ConflictException("Slot not available");
        }
        User user = userRepository.findByEmail(userEmail)
                .orElseThrow(() -> new com.example.exception.UnauthorizedException("User not found"));
        slot.setStatus(Slot.Status.BOOKED);
        slotRepository.save(slot);
        VenueSport vs = slot.getVenueSport();
        long hours = java.time.Duration.between(slot.getStartTime(), slot.getEndTime()).toHours();
        double price = vs.getPricePerHour() * hours;
        if (vs.getDiscountThresholdHours() != null && vs.getDiscountPercentage() != null
            && hours >= vs.getDiscountThresholdHours()) {
            price = price * (1 - vs.getDiscountPercentage() / 100.0);
        }
        Booking booking = Booking.builder()
                .user(user)
                .slot(slot)
                .totalAmount(price)
                .paymentStatus(Booking.PaymentStatus.PENDING)
                .build();
        booking = bookingRepository.save(booking);
        return BookingMapper.toDTO(booking);
    }

    // View user's own bookings
    public List<BookingDTO> getUserBookings(String userEmail) {
        return bookingRepository.findAll().stream()
                .filter(b -> b.getUser().getEmail().equals(userEmail))
                .map(BookingMapper::toDTO)
                .collect(Collectors.toList());
    }

    // Write a review
    @Transactional
    public ReviewDTO writeReview(Long venueId, String userEmail, Integer rating, String comment) {
        Venue venue = venueRepository.findById(venueId)
                .orElseThrow(() -> new com.example.exception.ResourceNotFoundException("Venue not found"));
        User user = userRepository.findByEmail(userEmail)
                .orElseThrow(() -> new com.example.exception.UnauthorizedException("User not found"));
        Review review = Review.builder()
                .venue(venue)
                .user(user)
                .rating(rating)
                .comment(comment)
                .build();
        review = reviewRepository.save(review);
        return ReviewMapper.toDTO(review);
    }
}
