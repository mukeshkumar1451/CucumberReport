package com.example.dto;

import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class BookingDTO {
    private Long id;
    @NotNull
    private UserDTO user;
    @NotNull
    private SlotDTO slot;
    @NotNull
    private Double totalAmount;
    @NotNull
    private String paymentStatus;
    private String qrCode;
}
