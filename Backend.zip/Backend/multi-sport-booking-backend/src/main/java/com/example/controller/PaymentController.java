package com.example.controller;

import com.example.service.PaymentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/payment")
public class PaymentController {
    @Autowired
    private PaymentService paymentService;

    // Endpoint to create a payment order (Stripe PaymentIntent)
    @PostMapping("/create-order/{bookingId}")
    public ResponseEntity<?> createPaymentOrder(@PathVariable Long bookingId) {
        try {
            String clientSecret = paymentService.createPaymentOrder(bookingId);
            return ResponseEntity.ok(Map.of("clientSecret", clientSecret));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    // Endpoint to handle Stripe webhook for payment verification
    @PostMapping("/webhook")
    public ResponseEntity<?> handleStripeWebhook(@RequestBody String payload,
                                                 @RequestHeader("Stripe-Signature") String sigHeader,
                                                 @RequestParam("endpointSecret") String endpointSecret) {
        try {
            var paymentDTO = paymentService.handleStripeWebhook(payload, sigHeader, endpointSecret);
            if (paymentDTO != null) {
                return ResponseEntity.ok(paymentDTO);
            } else {
                return ResponseEntity.ok("Event ignored or not a successful payment");
            }
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }
}
