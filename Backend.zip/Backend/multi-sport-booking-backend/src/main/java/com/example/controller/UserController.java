package com.example.controller;

import com.example.dto.BookingDTO;
import com.example.dto.ReviewDTO;
import com.example.dto.SlotDTO;
import com.example.dto.VenueDTO;
import com.example.service.UserService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import java.security.Principal;
import java.time.LocalDate;
import java.util.List;

@RestController
@RequestMapping("/api/user")
public class UserController {
    @Autowired
    private UserService userService;

    // List all venues
    @GetMapping("/venues")
    public List<VenueDTO> getAllVenues() {
        return userService.listAllVenues();
    }

    // Venue details + sports + slots
    @GetMapping("/venues/{venueId}")
    public VenueDTO getVenueDetails(@PathVariable Long venueId) {
        return userService.getVenueDetails(venueId);
    }

    // Slots by date for a sport
    @GetMapping("/venuesport/{venueSportId}/slots")
    public ResponseEntity<?> getSlotsByDate(@PathVariable Long venueSportId, @RequestParam("date") String date,
                                            @RequestParam(defaultValue = "0") int page,
                                            @RequestParam(defaultValue = "10") int size) {
        List<SlotDTO> allSlots = userService.getSlotsByDate(venueSportId, LocalDate.parse(date));
        int start = Math.min(page * size, allSlots.size());
        int end = Math.min(start + size, allSlots.size());
        List<SlotDTO> paged = allSlots.subList(start, end);
        return ResponseEntity.ok(java.util.Map.of(
            "content", paged,
            "total", allSlots.size()
        ));
    }

    // Book a slot
    @PostMapping("/bookings")
    public BookingDTO bookSlot(@RequestParam Long slotId, Principal principal) {
        return userService.bookSlot(slotId, principal.getName());
    }

    // View user's bookings
    @GetMapping("/bookings")
    public ResponseEntity<?> getUserBookings(Principal principal,
                                             @RequestParam(defaultValue = "0") int page,
                                             @RequestParam(defaultValue = "10") int size) {
        List<BookingDTO> allBookings = userService.getUserBookings(principal.getName());
        int start = Math.min(page * size, allBookings.size());
        int end = Math.min(start + size, allBookings.size());
        List<BookingDTO> paged = allBookings.subList(start, end);
        return ResponseEntity.ok(java.util.Map.of(
            "content", paged,
            "total", allBookings.size()
        ));
    }

    // Write a review
    @PostMapping("/reviews")
    public ReviewDTO writeReview(@RequestParam Long venueId, @RequestParam Integer rating, @RequestParam String comment, Principal principal) {
        return userService.writeReview(venueId, principal.getName(), rating, comment);
    }
}
