package com.example.service;

import com.example.entity.Booking;
import com.example.repository.BookingRepository;
import com.example.util.QRCodeUtil;
import jakarta.mail.MessagingException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class BookingConfirmationService {
    @Autowired
    private BookingRepository bookingRepository;
    @Autowired
    private EmailService emailService;

    public void sendBookingConfirmation(Long bookingId) throws Exception {
        Booking booking = bookingRepository.findById(bookingId)
                .orElseThrow(() -> new com.example.exception.ResourceNotFoundException("Booking not found"));
        String qrContent = "BookingID: " + booking.getId() + ", User: " + booking.getUser().getEmail() + ", Slot: " + booking.getSlot().getId();
        byte[] qrImage = QRCodeUtil.generateQRCodeImage(qrContent, 250, 250);
        String subject = "Booking Confirmation - MultiSport Booking";
        String text = "Dear " + booking.getUser().getName() + ",\nYour booking is confirmed. Please find your QR code attached.";
        emailService.sendBookingConfirmationWithQR(booking.getUser().getEmail(), subject, text, qrImage);
    }
}
