package com.example.service;

import com.example.dto.PaymentDTO;
import com.example.entity.Booking;
import com.example.entity.Payment;
import com.example.mapper.PaymentMapper;
import com.example.repository.BookingRepository;
import com.example.repository.PaymentRepository;
import com.stripe.Stripe;
import com.stripe.exception.StripeException;
import com.stripe.model.PaymentIntent;
import com.stripe.net.Webhook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.HashMap;
import java.util.Map;

@Service
public class PaymentService {
    @Value("${stripe.secret-key}")
    private String stripeSecretKey;

    @Autowired
    private PaymentRepository paymentRepository;
    @Autowired
    private BookingRepository bookingRepository;

    // Create Stripe PaymentIntent (order)
    public String createPaymentOrder(Long bookingId) throws StripeException {
        Stripe.apiKey = stripeSecretKey;
        Booking booking = bookingRepository.findById(bookingId)
                .orElseThrow(() -> new com.example.exception.ResourceNotFoundException("Booking not found"));
        Map<String, Object> params = new HashMap<>();
        params.put("amount", (int) (booking.getTotalAmount() * 100)); // Stripe expects amount in cents
        params.put("currency", "inr");
        params.put("metadata", Map.of("bookingId", bookingId.toString()));
        PaymentIntent intent = PaymentIntent.create(params);
        return intent.getClientSecret();
    }

    // Verify Stripe webhook signature and save payment details
    @Transactional
    public PaymentDTO handleStripeWebhook(String payload, String sigHeader, String endpointSecret) throws StripeException {
        com.stripe.model.Event event = Webhook.constructEvent(payload, sigHeader, endpointSecret);
        if ("payment_intent.succeeded".equals(event.getType())) {
            PaymentIntent intent = (PaymentIntent) event.getDataObjectDeserializer().getObject().get();
            Long bookingId = Long.valueOf(intent.getMetadata().get("bookingId"));
            Booking booking = bookingRepository.findById(bookingId)
                    .orElseThrow(() -> new com.example.exception.ResourceNotFoundException("Booking not found"));
            booking.setPaymentStatus(Booking.PaymentStatus.SUCCESS);
            bookingRepository.save(booking);
            Payment payment = Payment.builder()
                    .booking(booking)
                    .amount(booking.getTotalAmount())
                    .paymentGatewayId(intent.getId())
                    .status(Payment.Status.SUCCESS)
                    .build();
            payment = paymentRepository.save(payment);
            return PaymentMapper.toDTO(payment);
        }
        return null;
    }
}
