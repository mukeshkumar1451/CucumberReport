package com.example.dto;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.Data;

@Data
public class VenueDTO {
    private Long id;

    @NotNull
    private UserDTO vendor;

    @NotNull
    @Size(min = 2, max = 100)
    private String name;

    @NotNull
    private String address;

    @NotNull
    private String city;

    private String locationUrl;
    private String contactNumber;
    private String description;
    private String images; // JSON array string
    @NotNull
    private String status;
}
