package com.cognizant.collector.DatabaseCollector.controller;



import com.cognizant.collector.DatabaseCollector.service.DataTransferService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/data-transfer")
public class DataTransferController {

    @Autowired
    private DataTransferService dataTransferService;

    // Endpoint to transfer data from Userstories collection
    @GetMapping("/transfer/userstories")
    public String transferUserstories() {
        dataTransferService.transferUserstories();
        return "Data transferred from Userstories collection";
    }

    // Endpoint to transfer data from Defect collection
    @GetMapping("/transfer/defect")
    public String transferDefect() {
        dataTransferService.transferDefect();
        return "Data transferred from Defect collection";
    }

    // Endpoint to transfer data from TestCase collection
    @GetMapping("/transfer/testcase")
    public String transferTestCase() {
        dataTransferService.transferTestCase();
        return "Data transferred from TestCase collection";
    }

    // Endpoint to transfer data from all collections
    @GetMapping("/transfer/all")
    public String transferAllCollections() {
        dataTransferService.transferAllCollections();
        return "Data transferred from all collections";
    }
}


























//import com.cognizant.collector.DatabaseCollector.beans.RTS.Defect;
//import com.cognizant.collector.DatabaseCollector.beans.RTS.TestCase;
//import com.cognizant.collector.DatabaseCollector.beans.RTS.Userstories;
//import com.cognizant.collector.DatabaseCollector.service.DataTransferService;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.web.bind.annotation.*;
//
//@RestController
//@RequestMapping("/api/data-transfer")
//public class DataTransferController {
//
//    @Autowired
//    private DataTransferService dataTransferService;
//
//    @GetMapping("/fetch-data/{collectionName}")
//    public String fetchDataAndPrint(@PathVariable String collectionName) {
//        // Call service to transfer data for a specific collection
//        dataTransferService.transferCollection(collectionName, getPojoClass(collectionName));
//        return "Data fetching and printing completed for collection: " + collectionName;
//    }
//
//    @PostMapping("/transfer-all")
//    public String transferAllCollections() {
//        // Transfer all collections
//        dataTransferService.transferAllCollections();
//        return "Data transfer initiated for all collections.";
//    }
//
//    private Class<?> getPojoClass(String collectionName) {
//        switch (collectionName) {
//            case "Userstories":
//                return Userstories.class;
//            case "Defect":
//                return Defect.class;
//            case "testcase":
//                return TestCase.class;
//            default:
//                throw new IllegalArgumentException("Unknown collection: " + collectionName);
//        }
//    }
//}


