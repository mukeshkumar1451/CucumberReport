package com.cognizant.collector.DatabaseCollector.Scheduler;



import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.Date;

@Document(collection = "SchedulerInfo")
public class SchedulerInfo {

    @Id
    private String id;
    private String collectionName;
    private Date lastExecutionTime;

    // Constructors
    public SchedulerInfo() {}

    public SchedulerInfo(String collectionName, Date lastExecutionTime) {
        this.collectionName = collectionName;
        this.lastExecutionTime = lastExecutionTime;
    }

    // Getters and Setters
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getCollectionName() {
        return collectionName;
    }

    public void setCollectionName(String collectionName) {
        this.collectionName = collectionName;
    }

    public Date getLastExecutionTime() {
        return lastExecutionTime;
    }

    public void setLastExecutionTime(Date lastExecutionTime) {
        this.lastExecutionTime = lastExecutionTime;
    }

    @Override
    public String toString() {
        return "SchedulerInfo{" +
                "id='" + id + '\'' +
                ", collectionName='" + collectionName + '\'' +
                ", lastExecutionTime=" + lastExecutionTime +
                '}';
    }
}

