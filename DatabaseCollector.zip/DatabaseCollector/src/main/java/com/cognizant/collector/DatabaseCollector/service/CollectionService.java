package com.cognizant.collector.DatabaseCollector.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Service;

@Service
public class CollectionService {

    @Autowired
    private MongoTemplate mongoTemplate;

    // Method to explicitly create a collection
    public void createCollection(String collectionName) {
        // Create collection
        mongoTemplate.createCollection(collectionName);

        // Optionally, create indexes if required
        // mongoTemplate.indexOps(collectionName).ensureIndex(new Index().on("field", Direction.ASC));
    }
}

