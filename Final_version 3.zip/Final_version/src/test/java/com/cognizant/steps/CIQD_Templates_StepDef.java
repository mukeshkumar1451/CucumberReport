//Scripted By Abhishek Gouraj and Manisha Patil
 
package com.cognizant.steps;
 
import static java.lang.invoke.MethodHandles.lookup;
import static org.slf4j.LoggerFactory.getLogger;
 
import org.openqa.selenium.WebDriver;
import org.slf4j.Logger;
import org.testng.Assert;
 
import com.cognizant.framework.DriverManager;
import com.cognizant.pages.CIQD_ExistingTemplate_Page;
import com.cognizant.pages.CIQD_NewTemplate_Page;
//import com.cognizant.pages.CIQD_ExistingTemplate_Page;
//import com.cognizant.pages.IDashboard_NewTemplate_Page;
 
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
 
public class CIQD_Templates_StepDef extends MasterSteps {
 
	WebDriver driver = DriverManager.getWebDriver();
	final static Logger log = getLogger(lookup().lookupClass());
	CIQD_NewTemplate_Page Newtemplate = new CIQD_NewTemplate_Page(driver);
	CIQD_ExistingTemplate_Page Existingtemplate = new CIQD_ExistingTemplate_Page(driver); 

 
	@When("User clicks on Project Tab")
	public void user_clicks_on_project_tab() {
		Newtemplate.clickOnProjectTab();
		attachScreenshotForWeb();
	}
 
	@And("User clicks on Existing Dashboard")
	public void user_clicks_on_existing_dashboard() {
		Newtemplate.PRJDashboard();
		attachScreenshotForWeb();
	}
 
	@And("User clicks on Add Dashboard Template button and enters Template Name")
	public void user_clicks_on_add_dashboard_template_button_and_enters_template_name() {
		Newtemplate.CreateTempBtn();
		attachScreenshotForWeb();
		Newtemplate.TempName();
		attachScreenshotForWeb();
	}
 
	@And("User clicks on Create button")
	public void user_clicks_on_create_button() {
		Newtemplate.CrtButton();
		attachScreenshotForWeb();
	}
 
	@Then("User is able to create New Template")
	public void user_is_able_to_create_new_template() {
		String ActualResult = Newtemplate.getPopupMessage();
		String ExpectedResult = "template added successfully";
		Assert.assertEquals(ExpectedResult, ActualResult);
		log.info("User is able to create New Template");
		attachScreenshotForWeb();
	}
 
	@And("User selects Existing Project")
	public void user_selects_existing_project() {
		Existingtemplate.PRJDashboard();
		attachScreenshotForWeb();
	}
 
	@And("User clicks on Create Dashboard option")
	public void user_clicks_on_create_dashboard_option() {
		Existingtemplate.CreateDashboard();
		attachScreenshotForWeb();
	}
 
	@And("User enters Dashboard name and user selects existing Template")
	public void user_enters_dashboard_name_and_user_selects_existing_template() {
		Existingtemplate.DsahboardName();
		Existingtemplate.SelectTemplate();
		Existingtemplate.ChooseTemplate();
		attachScreenshotForWeb();
	}
 
	@And("User clicks on Import button")
	public void user_clicks_on_import_button() {
		Existingtemplate.Import();
		attachScreenshotForWeb();
	}
	@Then("User can view the Existing Template")
	public void user_can_view_the_existing_template() {
		String ActualResult = Existingtemplate.verifyExistingTemplate(); 
		String ExpectedResult = "default"; 
		Assert.assertEquals(ExpectedResult,ActualResult);
		attachScreenshotForWeb();
	    log.info("User can view the Existing Template");
	}
 
}