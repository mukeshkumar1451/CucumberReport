//Developed By: Abhijit Lipane, Nidhi Singh, Akash Panchal, Vijay Raskar and Shrikant Rahane
//Refactored By: Aditya Dharmapurikar, Abhijit Lipane, Manisha Patil

package com.cognizant.steps;

import static java.lang.invoke.MethodHandles.lookup;
import static org.slf4j.LoggerFactory.getLogger;
import org.openqa.selenium.WebDriver;
import org.slf4j.Logger;
import org.testng.Assert;
import com.cognizant.framework.DriverManager;
import com.cognizant.pages.CIQD_LobPage;
import com.cognizant.pages.CIQD_OrgPage;
import com.cognizant.pages.CIQD_ProjectPage;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

	public class CIQD_ProjectManagementStepDef extends MasterSteps {
	
	WebDriver driver = DriverManager.getWebDriver();
	final static Logger log = getLogger(lookup().lookupClass());
	
	//Objects for LOB and ORG Page
	CIQD_OrgPage orgPageObj = new CIQD_OrgPage(driver);
	CIQD_LobPage lobPageObj = new CIQD_LobPage(driver);
	CIQD_ProjectPage createProjectObj = new CIQD_ProjectPage(driver);
	
	//Method to Create ORG with valid Credentials
	@Given("User Create ORG with valid Details {string} {string}")
	public void user_Create_ORG_with_valid_details(String string, String string2) {
		orgPageObj.createOrg(string,string2);
		attachScreenshotForWeb();
	}
	
	//Method to get the pop-up Text message for ORG Successfull Creation
	@Then("User Gets Successfull ORG Created Messegae")
	public void user_gets_successfull_org_created_messegae() {
		orgPageObj.orgCreated_msg();
		attachScreenshotForWeb();
	}
	
	//Method to get the Error pop-up Text message and validate the message for ORG Unsuccessful Creation
	@Then("User gets Error Messegae")
	public void User_gets_Error_Messegae() {
		orgPageObj.Error_Msg();
		attachScreenshotForWeb();
		String ActualTitle = orgPageObj.Error_Msg();
		String ExpectedTitle = "please provide valid inputs";
		Assert.assertEquals(ExpectedTitle, ActualTitle);
		log.info("Cannot create ORG");
	}
	
	//Method to add Details for LOB Creation in the Fields
	@Given("User Add Lob Details in New Lob Section{string} {string}")
	public void User_Add_Lob_Details_in_New_Lob_Section(String LobName , String LobDescription) {
		lobPageObj.fillLobDetails(LobName,LobDescription);
		attachScreenshotForWeb();
	}
	
	//Method to add Valid organization details for LOB creation in the Fields
	@Then("User Create Lob with valid Organization Name {string}")
	public void User_Create_Lob_with_valid_Organization_Name(String OrgName) throws InterruptedException {
		lobPageObj.createLobWithOrg(OrgName);
		attachScreenshotForWeb();
	}
	
	//Method to create LOB without Organization details
    @When("User attempt without Organization name")
	public void User_attempt_without_Organization_name() {
    	lobPageObj.createLobWithOutOrg();
    	attachScreenshotForWeb();
    }
    
    //Method to get the Error text pop-up message and validate the message for unsuccessful LOB creation
    @Then("Error message is display")
    public void Error_message_is_display() {
    	lobPageObj.Error_Msg();
    	attachScreenshotForWeb();
		String ActualTitle = lobPageObj.Error_Msg();
		String ExpectedTitle = "please provide valid inputs";
		Assert.assertEquals(ExpectedTitle, ActualTitle);
    	log.info("Cannot Create LOB");
    	
    }
	
    //Method to Select the New Project Tab after clicking project Tab in Homepage
    @Then("Select New Project option By Click on Project Menu")
	public void Select_New_Project_option_By_Click_on_Project_Menu() {
		createProjectObj.clickOnProjectMenu();
		attachScreenshotForWeb();
	}
 
    //Method to Enter Project Details for New Project Creation
	@Given("User enters {string} {string} {string} and {string}")
	public void user_enters_project_name_description_lob_and_source_tool(String prjName, String description, String lob,
			String srcTool) {
		createProjectObj.enterProjectDetails(prjName, description, lob, srcTool);
		attachScreenshotForWeb();
	}
 
	//Method to Create New Project By clicking on Create Project Button
	@Then("Create New Project")
	public void Create_New_Project() {
		createProjectObj.clickOnCreateBtn();
		attachScreenshotForWeb();
	}
 
	//Method to get the Error Message and validate the message for unsuccessful Project Creation
	@Then("Popup Message should be displayed")
	public void Popup_Message_should_be_displayed() {
		String ActualTitle = createProjectObj.getPopUpMsg();
		attachScreenshotForWeb();
		System.out.print(ActualTitle);
		String ExpectedTitle = "please provide valid inputs";
		Assert.assertEquals(ExpectedTitle, ActualTitle);
		log.info("cannot create the project");
//		String ActualTitle = createProjectObj.projectCreationPopUpMsg();
	}
	
	//19-01-2024 Friday
			@Given("User Create ORG with valid Details")
			public void user_Create_ORG_with_valid_details() {
				String OrgName=properties.getProperty("OrgName");
				String OrgDescription=properties.getProperty("OrgDescription");
				orgPageObj.createOrg(OrgName,OrgDescription);
				attachScreenshotForWeb();
			
		}
			@Given("User Add Lob Details in New Lob Section")
			public void User_Add_Lob_Details_in_New_Lob_Section() {
				String LobName=properties.getProperty("LobName");
				String LobDescription=properties.getProperty("LobDescription");
				lobPageObj.fillLobDetails(LobName,LobDescription);
				attachScreenshotForWeb();
			}
			
			@Then("User Create Lob with valid Organization Name")
			public void User_Create_Lob_with_valid_Organization_Name() throws InterruptedException{
				String OrgName=properties.getProperty("OrgName");
				lobPageObj.createLobWithOrg(OrgName);
				attachScreenshotForWeb();
			}
			
			@Given("User enters valid Project")
			public void user_enters_project_name_description_lob_and_source_tool() {
				String prjName=properties.getProperty("prjName");
				String prjDescription=properties.getProperty("prjDescription");
				String LobName=properties.getProperty("LobName");
				String srcTool=properties.getProperty("srcTool");
				createProjectObj.enterProjectDetails(prjName, prjDescription, LobName, srcTool);
				attachScreenshotForWeb();
			}
 
}