//Developed By: Aditya Dharmapurikar and Vaishnavi Zarad
//Refactored By: Aditya Dharmapurikar and Kalyani Chaudhary
package com.cognizant.steps;

import static java.lang.invoke.MethodHandles.lookup;
import static org.slf4j.LoggerFactory.getLogger;

import org.openqa.selenium.WebDriver;
import org.slf4j.Logger;
import org.testng.Assert;

import com.cognizant.framework.DriverManager;
import com.cognizant.pages.CIQD_BasePage;
import com.cognizant.pages.CIQD_LoginPage;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class CIQD_LoginStepDef extends MasterSteps {
	
	WebDriver driver = DriverManager.getWebDriver();
	final static Logger log = getLogger(lookup().lookupClass());
	CIQD_LoginPage InitLoginPage = new CIQD_LoginPage(driver);
	CIQD_BasePage basePageObj = new CIQD_BasePage(driver);
	
	String userName = properties.getProperty("userName");
	String password = properties.getProperty("Password");
	
	//Updated Login Feature:
	
   //Updated Login Feature
    
    @Given("User is on login page")
    public void user_is_on_login_page() {
    	String appUrl = properties.getProperty("ApplicationUrl");
    	driver.get(appUrl);
		attachScreenshotForWeb();
    }

    @When("User enters Username in idashboard")
    public void user_enters_username_in_idashboard() {    	
    	InitLoginPage.enteruserName(userName);
		attachScreenshotForWeb();

    }

    @When("User enters Password in idashboard")
    public void user_enters_password_in_idashboard() {
    	InitLoginPage.enterPassword(password);
		attachScreenshotForWeb();

    }

    @When("User clicks on Login button")
    public void user_clicks_on_login_button() {
    	InitLoginPage.clickOnLoginButton();
		attachScreenshotForWeb();

    }
	
	
	//Method to launch URL and Login with Given Credentials
	@Given("User is logged into Idashboard website with Valid Credentials")
	public void user_is_logged_into_Idashboard_website_with_Valid_Credentials() {
    	String appUrl = properties.getProperty("ApplicationUrl");
    	driver.get(appUrl);
    	InitLoginPage.loginIntoCIQD(userName, password);
		attachScreenshotForWeb();
    }
	
	//Method to Verify the Username of the User
    @And("User verifies Username in dashboard")
    public void user_verifies_Username_in_dashboard() {
    	basePageObj.clickOnUserDropdown();
    	String userName = properties.getProperty("userName");
        InitLoginPage.Profile_Validation(userName);
        attachScreenshotForWeb();
    }
       
    //Method to Logout from the Idashboard
    @Then("User logout from the Dashboard")
    public void user_logout_from_the_Dashboard() {
    	basePageObj.logOut();
    	attachScreenshotForWeb();
    }
    
    //Method to Verify if the Login button is clickable or Not
    @Then("Verify the Login button is enabled")
    public void Verify_the_Login_button_is_disabled() {
    	InitLoginPage.LoginBtnStatus();
    	attachScreenshotForWeb();
    }
    
    //developed by Vaishnavi Zarad
    //Method to check if the user is logging in with valid credentils
    @When("User is logged into idashboard website with invalid username {string} and password {string}")
    public void user_is_logged_into_idashboard_website_with_invalid_username_and_password(String userName, String Password) {
//    	String appUrl = properties.getProperty("ApplicationUrl");
//    	driver.get(appUrl);
    	InitLoginPage.loginIntoCIQD(userName, password);
		attachScreenshotForWeb();

    }
    
    //developed by Vaishnavi Zarad
    //Method to Verify the HomePage
    @Then("User gets Error message")
	public void user_verifies_homepage() {
    	
		String ActualTitle = basePageObj.getPopupMessage();
		String ExpectedTitle1 = "logged in as 'Vaishnavi Zarad'";
		String ExpectedTitle2 = "User (Vaishnavi@cts) Not Found!";
		String ExpectedTitle3 = "User account Vaishnavi@cts.com is disabled. Please contact administrator.";
 
		if (ActualTitle.equals(ExpectedTitle1)) {
			Assert.assertEquals(ExpectedTitle1, ActualTitle);
			log.info("logged in as 'Vaishnavi Zarad'");
			attachScreenshotForWeb();
 
		} else if (ActualTitle.equals(ExpectedTitle2)) {
			Assert.assertEquals(ExpectedTitle2, ActualTitle);
			log.info("User (Vaishnavi@cts) Not Found!");
			attachScreenshotForWeb();
 
		} else {
			Assert.assertEquals(ExpectedTitle3, ActualTitle);
			log.info("invalid email id/password");
			attachScreenshotForWeb();
 
		}
		driver.quit();
 
	}
 

}
