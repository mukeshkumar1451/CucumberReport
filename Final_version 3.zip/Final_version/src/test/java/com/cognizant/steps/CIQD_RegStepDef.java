//Developed by Shivani, Dinesh and Prafull

package com.cognizant.steps;

import static java.lang.invoke.MethodHandles.lookup;
import static org.slf4j.LoggerFactory.getLogger;

import org.openqa.selenium.WebDriver;
import org.slf4j.Logger;
import org.testng.Assert;

import com.cognizant.framework.DriverManager;
import com.cognizant.pages.CIQD_LoginPage;
import com.cognizant.pages.CIQD_RegistrationPage;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class CIQD_RegStepDef extends MasterSteps {

	WebDriver driver = DriverManager.getWebDriver();
	final static Logger log = getLogger(lookup().lookupClass());
	CIQD_RegistrationPage registerPage;
	CIQD_LoginPage loginPage;

	public CIQD_RegStepDef() {
		loginPage = new CIQD_LoginPage(driver);
		registerPage = new CIQD_RegistrationPage(driver);
	}
	
	
	// Method verifies that user navigates to Register Account page
	@Given("User navigates to Register Account page")
	public void launch() {
		String appUrl = properties.getProperty("ApplicationUrl");
		registerPage.launchUrl();
		attachScreenshotForWeb();
		loginPage.clickOnCreateAccountLink();
	}
	
	
	// Method verifies that user is able to enter details and clicks on create account button
	@When("User enters {string},{string},{string},{string},{string} details")
	public void user_enters_details_and_clicks_create_account_button(String FirstName, String LastName, String EmailId,
			String Password, String ConfirmPassword) {
		registerPage.enterFirstName(FirstName);
		registerPage.enterLastName(LastName);
		registerPage.enterEmailID(EmailId);
		registerPage.enterPassword(Password);
		registerPage.enterConfirmedPassword(ConfirmPassword);
		attachScreenshotForWeb();
	}

	@And("User clicks Create Account button")
	public void clicks_Create_Account_button() {
		registerPage.clickOnCreateAccount();
		attachScreenshotForWeb();
	}

	// Method verifies that User able to Create new Account
	@Then("Verify the User creates new account")
	public void verify_the_User_creates_new_account() {
		String successmessage = registerPage.getPopupMessage();
		String expectedMessage = "user created successfully";
		// Assert verify that user is created new account 
		Assert.assertEquals(successmessage, expectedMessage);
    	log.info("User is able to create new account Successfully");
		log.info("Success Message: " + successmessage);
		attachScreenshotForWeb();
	}

	// Method verifies that user get proper warning message about existing account
	@Then("Verify User should get a proper warning about existing Account")
	public void verify_user_should_get_a_proper_warning_about_duplicate_username() {
		String EmailId=properties.getProperty("EmailId");
		String Actualerrorsmessage = registerPage.getPopupMessage();
		System.out.println("Actual: "+Actualerrorsmessage);
		String ExpectedexpectedMessage = "User, with Email : "+ "'"+EmailId+"'"+" already exists";
		System.out.println("Expected: "+ExpectedexpectedMessage);
		//Assert verify that user get proper warning message about existing account
		Assert.assertEquals(Actualerrorsmessage, ExpectedexpectedMessage); 
    	log.info("User is able to get a proper warning about existing Account");
		log.info("Error Message: " + Actualerrorsmessage);
		attachScreenshotForWeb();
	}

	//Method verifies that account button is enabled or NOT
	@Then("verify create account button is enabled")
	public void verify_create_account_button_is_disable_or_not() {
		registerPage.createAccountDisable();
		attachScreenshotForWeb();	
	}

	// method verifies if the user is able to clicks on eye icon
	@When("User clicks on eye icon")
	public void user_clicks_on_eye_icon() {
		registerPage.clickOnEyeIcon();
		attachScreenshotForWeb();
	}

	//method verify that User is able to see password in decrypted format
	@Then("Verify password is decrypted")
	public void verify_password_is_decrypted() {
		attachScreenshotForWeb();
	}
	
	//19-01-2024
		// Method verifies that user is able to enter details and clicks on create account button
			@When("User enters valid details")
			public void user_enters_details_and_clicks_create_account_button() {
				String FirstName=properties.getProperty("FirstName");
				 String LastName=properties.getProperty("LastName");
				 String EmailId=properties.getProperty("EmailId");
				 String Password=properties.getProperty("RegPassword");
				 String ConfirmPassword=properties.getProperty("ConfirmPassword");
				registerPage.enterFirstName(FirstName);
				registerPage.enterLastName(LastName);
				registerPage.enterEmailID(EmailId);
				registerPage.enterPassword(Password);
				registerPage.enterConfirmedPassword(ConfirmPassword);
				attachScreenshotForWeb();
			}
}
