//Scripted By Prasad Bhadke and Shreshth Roy
 
package com.cognizant.steps;
 
import static java.lang.invoke.MethodHandles.lookup;
import static org.slf4j.LoggerFactory.getLogger;
 
import org.openqa.selenium.WebDriver;
import org.slf4j.Logger;
import org.testng.Assert;
 
import com.cognizant.framework.DriverManager;
import com.cognizant.pages.CIQD_LoginPage;
import com.cognizant.pages.CIQD_MetricsPage;
import com.cognizant.pages.CIQD_RolesPage;
import com.cognizant.pages.CIQD_TeamsPage;
import com.cognizant.pages.CIQD_TemplatesPage;
 
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
public class CIQD_Settings_StepDef extends MasterSteps {
 
	final static Logger log = getLogger(lookup().lookupClass());

	WebDriver driver = DriverManager.getWebDriver();
	String appUrl = properties.getProperty("ApplicationUrl");
	CIQD_LoginPage idashboardlogin = new CIQD_LoginPage(driver);
	CIQD_RolesPage rolesPage = new CIQD_RolesPage(driver);
	CIQD_TeamsPage teamsPage= new CIQD_TeamsPage(driver);
	CIQD_MetricsPage idashboardmetrics = new CIQD_MetricsPage(driver);
	CIQD_TemplatesPage templatesPage = new CIQD_TemplatesPage(driver);

	@Given("User is logged into Idashboard website with Valid Admin Credentials")
	public void user_navigates_to_the_application_login_page_with_Valid_Admin_Credentials() {
		String appUrl = properties.getProperty("ApplicationUrl");
		String Username1 = properties.getProperty("UserName1");
		String Password1 = properties.getProperty("Password1");
		System.out.println(Username1+" "+Password1);
		idashboardlogin.launchUrl();
		driver.get(appUrl);
		idashboardlogin.loginIntoCIQD(Username1,Password1);
		attachScreenshotForWeb();
	}

	@Given("User is on Homepage")
	public void user_is_on_homepage() {
		idashboardlogin.getNameOfTheUser();
		//screenshot and log info should be added here and in every step
		attachScreenshotForWeb();
	}
	@When("User clicks on User Profile icon")
	public void user_clicks_on_user_profile_icon() {
		rolesPage.clickOnUserDropdown();
		attachScreenshotForWeb();
	}
	@And("User clicks on Profile option")
	public void user_clicks_on_profile_option() {
		rolesPage.clickOnProfile();
		attachScreenshotForWeb();
	}
	@Then("User is able to verify Profile")
	public void user_is_able_to_verify_profile() {
		String ActualResult = rolesPage.verifyProfilePage(); 
		String ExpectedResult = "Admin User1"; 
		Assert.assertEquals(ExpectedResult,ActualResult);
		System.out.println("User is able to verify Profile");
		attachScreenshotForWeb();
	}
	@And("User clicks on Admin Settings option")
	public void user_clicks_on_admin_settings_option() {
		rolesPage.clickOnAdminSettings();
		attachScreenshotForWeb();
	}
	@Then("User is on Users Tab and is able to see Existing users")
	public void user_is_on_users_tab_and_is_able_to_see_existing_users() {
		String ActualResult = rolesPage.verifyExistingUsers(); 
		String ExpectedResult = "Users"; 
		Assert.assertEquals(ExpectedResult,ActualResult);
		System.out.println("User is on Users Tab and is able to see Existing users");
		attachScreenshotForWeb();
	}
	@And("User clicks on Roles option")
	public void user_clicks_on_roles_option() {
		rolesPage.navigateToRoleOption();
		attachScreenshotForWeb();
	}
	@Then("User is able to Add New Role")
	public void user_is_able_to_add_new_role() {
		rolesPage.clickOnAddNewRollButton();
		rolesPage.clickOnCreateRole();
		String ActualResult = rolesPage.verifyNewRoleAdded(); 
		String ExpectedResult = "Manage Roles"; 
		Assert.assertEquals(ExpectedResult,ActualResult);
		attachScreenshotForWeb();
	}
	@Then("User is able to View Existing Role")
	public void user_is_able_to_view_existing_role() {
		String ActualResult = rolesPage.verifyExistingRoles(); 
		String ExpectedResult = "Roles"; 
		Assert.assertEquals(ExpectedResult,ActualResult);
        log.info("User is able to View Existing Role");
		attachScreenshotForWeb();
	}
	@And("User clicks on Teams option")
	public void user_clicks_on_teams_option() {
		teamsPage.navigateToTeams();
		attachScreenshotForWeb();
	}
	@Then("User creates New Team")
	public void user_creates_new_team() {
		teamsPage.createNewTeam();
		String ActualResult = teamsPage.verifyAddNewTeam(); 
		String ExpectedResult = "ADD NEW"; 
		Assert.assertEquals(ExpectedResult,ActualResult);
		attachScreenshotForWeb();
	}
	@Then("User views Existing Teams")
	public void user_views_existing_teams() {
		teamsPage.viewExistingTeams();
		String ActualResult = teamsPage.verifyExistingTeam(); 
		String ExpectedResult = "Manage Teams"; 
		Assert.assertEquals(ExpectedResult,ActualResult);
		attachScreenshotForWeb();
	}
	@And("User clicks on Metrics option")
	public void user_clicks_on_metrics_option() {
		idashboardmetrics.clickOnMetric();
		attachScreenshotForWeb();
	}
	@Then("User creates New Metrics")
	public void user_creates_new_metrics() {
		idashboardmetrics.addDetailsOfMetric();
		String ActualResult = idashboardmetrics.verifyNewMetrics(); 
		String ExpectedResult = "ADD NEW"; 
		Assert.assertEquals(ExpectedResult,ActualResult);
		attachScreenshotForWeb();
	}
	@Then("User is able to view Existing Metrics")
	public void user_is_able_to_view_existing_metrics() {
		idashboardmetrics.viewMetric();
		String ActualResult = idashboardmetrics.verifyExistingMetrics(); 
		String ExpectedResult = "C2M_ExecutionSummary"; 
		Assert.assertEquals(ExpectedResult,ActualResult);
		attachScreenshotForWeb();
	}
	@And("User clicks on Templates option")
	public void user_clicks_on_templates_option() {
		templatesPage.ClickonTemplates();
		attachScreenshotForWeb();
	}
	@Then("User is able to view list of Templates")
	public void user_is_able_to_view_list_of_templates() {
		String ActualResult = templatesPage.verifyTemplatePage(); 
		String ExpectedResult = "Templates"; 
		Assert.assertEquals(ExpectedResult,ActualResult);
		log.info("User is able to view list of Templates");
		attachScreenshotForWeb();
	}
	@And("User clicks on drop-down icon from one of the Existing Templates")
	public void user_clicks_on_drop_down_icon_from_one_of_the_existing_templates() {
		templatesPage.ClickonMyTemplate();
		attachScreenshotForWeb();
	}
	@And("User clicks on Default drop-down icon to view Default Templates")
	public void user_clicks_on_default_drop_down_icon_to_view_default_templates() {
		templatesPage.ClickonDefault();
		attachScreenshotForWeb();
	}
	@Then("User is able to view Default Templates")
	public void user_is_able_to_view_default_templates() {
		String ActualResult = templatesPage.verifyDefaultTemplate(); 
		String ExpectedResult = "default"; 
		Assert.assertEquals(ExpectedResult,ActualResult);
		attachScreenshotForWeb();
		log.info("User is able to view default Templates Successfully");
	}
}