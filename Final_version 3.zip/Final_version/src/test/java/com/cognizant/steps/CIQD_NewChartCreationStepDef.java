//Developed and Refactored by Akash Panchal and Vijay Raskar

package com.cognizant.steps;
 
import static java.lang.invoke.MethodHandles.lookup;

import static org.slf4j.LoggerFactory.getLogger;
 
import org.openqa.selenium.WebDriver;

import org.slf4j.Logger;

import org.testng.Assert;
 
import com.cognizant.framework.DriverManager;

import com.cognizant.pages.CIQD_LoginPage;

import com.cognizant.pages.CIQD_NewChartsCreationPage;
 
import io.cucumber.java.en.Given;

import io.cucumber.java.en.Then;

import io.cucumber.java.en.When;
 
public class CIQD_NewChartCreationStepDef extends MasterSteps {
 
	WebDriver driver = DriverManager.getWebDriver();
	final static Logger log = getLogger(lookup().lookupClass());
	String userName = properties.getProperty("UserName");
	String password = properties.getProperty("Password");
	CIQD_NewChartsCreationPage newChartCreation;
	CIQD_LoginPage loginPage;

	public CIQD_NewChartCreationStepDef() {
		newChartCreation = new CIQD_NewChartsCreationPage(driver);
		loginPage = new CIQD_LoginPage(driver);
	}
 
	@When("User clicks on Project and opens an existing project dashboard")
	public void user_clicks_on_Project_and_opens_an_existing_project_dashboard() {
		newChartCreation.clickProject();
		newChartCreation.existingDashboardsClick();
		attachScreenshotForWeb();
	}
 
	@When("Click on the edit dashboard icon")
	public void click_on_the_edit_dashboard_icon() {
		newChartCreation.editPencilClick();
		attachScreenshotForWeb();
 
	}
 
	@When("Drags and Drops a new chart")
	public void drags_and_drops_a_new_chart() {
		newChartCreation.addNewChart();
		newChartCreation.reSizeNewChart();
		attachScreenshotForWeb();
	}
 
 
	@When("User is able to Select Card Chart from JIRA item type")
	public void user_is_able_to_Select_Card_Chart_from_JIRA_item_type() {
		newChartCreation.navigateToJIRADataSource();
		attachScreenshotForWeb();
	}
 
	@Given("User is on data source")
	public void user_is_on_data_source() {
		newChartCreation.verifyDataSourcePage();
		attachScreenshotForWeb();
	}

	@When("User click on Info and provide Name and Description")
	public void user_click_on_info_and_provide_name_and_Description() {
		newChartCreation.infoSection();
		attachScreenshotForWeb();
	}
 
	@When("click on Data")
	public void click_on_data() {
		newChartCreation.dataClick();
		attachScreenshotForWeb();
	}
 
	@When("select Group from GroupBy dropdown")
	public void select_from_group_by_dropdown() {
		newChartCreation.dataSection("statusName");
		attachScreenshotForWeb();
	}
 
	@When("Select Field from Aggregrate dropdown")
	public void select_from_Field_by_dropdown() {
		newChartCreation.aggregate("priorityId");
		attachScreenshotForWeb();
	}
 
	@When("User click on options and provide Chart Title")
	public void User_click_on_options_and_provide_Chart_Title() {
		String title = properties.getProperty("ChartTitle");
		newChartCreation.optionsClick(title);
		attachScreenshotForWeb();
	}

	@When("Click on save Chart icon and Click on save Dashboard and Click on cancel Icon")
	public void click_on_save_chart_icon_and_Click_on_save_Dashboard_and_Click_on_cancel_Icon() {
		newChartCreation.saveDashboard();
		attachScreenshotForWeb();
		newChartCreation.clickOnCancelIcon();
		newChartCreation.clickOnRefreshIcon();
		
	}
 
	@Then("New Chart is created Successfully")
	public void new_chart_is_created_successfully() {
	    newChartCreation.NewChartCreatedMsg();
	    attachScreenshotForWeb();
	}

}
