package com.cognizant.pages;
 
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
 
public class CIQD_ExistingTemplate_Page extends CIQD_BasePage {
 
	private WebDriver driver;
 
	public CIQD_ExistingTemplate_Page(WebDriver driver) {
		super(driver);
		this.driver = driver;
	}
 
	private By ProjectTab = By.xpath("//label[@title='Project']");
	private By PRJDashboard = By.xpath("(//button[@class='btn btn-sm btn-link'])[1]");
	private By CreateDashboard = By.xpath("//*[@title='Create Dashboard' and @type='button']");
	private By DsahboardName = By.xpath("//*[@name='newDashBoardName' and @type='text']");
	private By SelectTemplate = By.xpath("//*[text()=' Select a template']");
	private By ChooseTemplate = By.xpath("//*[text()=' Sample Template']");
	private By Import = By.xpath("//*[@type='button' and text()='Import']");
	private By ExistingTemplate = By.xpath("//*[text()='default']");
 
	public void ProjectTab() {
		clickOnWebElement(ProjectTab);
	}
 
	public void PRJDashboard() {
		clickOnWebElement(PRJDashboard);
	}
 
	public void CreateDashboard() {
		clickOnWebElement(CreateDashboard);
	}
 
	// Providing the DsahboardName
	public void DsahboardName() {
		String CreateDashboard = properties.getProperty("DashboardName");
		driver.findElement(DsahboardName).sendKeys(CreateDashboard);
		System.out.println("Dashboard Name entered : " + CreateDashboard);
	}
	public void SelectTemplate() {
		clickOnWebElement(SelectTemplate);
	}
 
	public void ChooseTemplate() {
		clickOnWebElement(ChooseTemplate);
	}
 
	public void Import() {
		clickOnWebElement(Import);
	}
	public String verifyExistingTemplate() {
		String existingTemplate = getTextOnWebElement(ExistingTemplate);
		return existingTemplate;
	}
 
}