// Scripted By Tanmay Mirane and Refactored by Prasad Bhadke 

package com.cognizant.pages;

import org.openqa.selenium.WebDriver;

public class CIQD_ProfilePage extends CIQD_BasePage {
 
	public CIQD_ProfilePage(WebDriver driver) {
		super(driver);
	}
}