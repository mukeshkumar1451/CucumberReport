//Developed By : Abhijit Lipane, Preeti Pal and Manisha Patil
//Refactored By : Abhijit Lipane and Manisha Patil

package com.cognizant.pages;
 
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
public class CIQD_ProjectPage extends CIQD_BasePage {
 
	//Locators 
	private By selOpt=By.id("clr-form-control-4");
	private By prjDrpDown = By.xpath("//label[@title='Project']");
	private By SelNewProjectLocator = By.xpath("//span[contains(text(),'New Project')]");
	private By ProjectNamePathLocator = By.xpath("//input[@name='name']");
	private By ProjectDescriptionLocator = By.xpath("//input[@name='description']");
	private By ProjectLobDropDownLocator = By.xpath("//select[@name='lobId']");// select class
	private By SourceToolDrpDownLocator = By.xpath("//div[@class='mat-select-arrow-wrapper']");
	private By CreateBtnPathLocator = By.xpath("//button[contains(text(),'Create')]");
	private By PopUpLocatorMessage = By.cssSelector("div[aria-label='please provide valid inputs']");
 
	// Constructor of CIQD_Create_New_Project_Page Class
	public CIQD_ProjectPage(WebDriver driver) {
		super(driver);
		this.driver = driver;
		driver.manage().window().maximize();
	}
	
	// Method to Click on Project Menu and then on New Project Tab
	public void clickOnProjectMenu() {
		waitFor(1000);
		clickOnWebElement(prjDrpDown);
		clickOnWebElement(SelNewProjectLocator);
	}
	
	//Method to Enter all mandatory Details required to create new project
	public void enterProjectDetails(String prjName, String description, String lob, String srcTool) {
		System.out.println(prjName+""+description+""+lob+""+srcTool);
		waitFor(1000);
		sendKeysOnWebElement(ProjectNamePathLocator,prjName);
		sendKeysOnWebElement(ProjectDescriptionLocator,description);
		waitFor(1000);
		selectByVisibleText(ProjectLobDropDownLocator,lob);
		waitFor(1000);
		clickOnWebElement(SourceToolDrpDownLocator);
		WebElement selOpt=driver.findElement(By.xpath("//span[contains(text(),'"+srcTool+"')]"));
		selOpt.click();
		
	}
	
	//Method to enter partial details i.e only Project Name and LOB
	public void enterPartialProjectDetails(String prjName, String lob) {
		sendKeysOnWebElement(ProjectLobDropDownLocator,prjName);
		selectByVisibleText(SourceToolDrpDownLocator,lob);
	}
	
	//Method to click project create button
	public void clickOnCreateBtn() {
		clickElementByJavaScript(CreateBtnPathLocator);
	}
	
	//Method to extract text from Pop-Up after Unsuccessful Project Creation
	public String getPopUpMsg() {
		// move to the element
		moveToElement(PopUpLocatorMessage);		
		return getTextOnWebElement(PopUpLocatorMessage);
	}
}
