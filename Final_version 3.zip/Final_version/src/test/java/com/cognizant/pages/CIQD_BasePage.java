package com.cognizant.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class CIQD_BasePage extends CIQD_Generics {

	public CIQD_BasePage(WebDriver driver) {
		super(driver);
		this.driver = driver;
	}


	// GroupA
	// Xpath used for ORG , LOB , Project , ProfileDropDown in the code
	private By HomePageOrgBarLocator = By.xpath("//label[text()='ORG']");
	protected By HomePagelobTabLocator = By.xpath("//label[text()='LOB']");
	protected By HomePageProjectTabLocator = By.xpath("//label[text()='Project']");
	private By popupMessage = By.xpath("//div[@class='toast-message ng-star-inserted']");
	protected By HomePageProfileDropDownLocator = By.xpath("//div[@class= 'user-icon dropdown-toggle']");
	private By HomePageDropDownAdminSettingOptionLocator = By.xpath("//label[@title='Admin Settings']");
	private By HomePageDropDownLogOutBtnLocator = By.xpath("//label[@class='dropdown-item'][2]");
    private By HomePageDropDownProfileLocator = By.xpath("//*[@id='clr-id-73' or @title='Profile']");	

	// GroupC (Dinesh, Preeti and Rohit)
    // To click on project
	public void clickProject() {
		try {
			waitUntilElementLocated(HomePageProjectTabLocator, 6000);
			clickOnWebElement(HomePageProjectTabLocator);
		} catch (Exception e) {
			clickOnWebElementByActionsClass(HomePageProjectTabLocator);
		}
	}

	
	// To get PopUp Message
	public String getPopupMessage() {
		waitFor(3000);
		String errorMsg = getTextOnWebElement(popupMessage);
		return errorMsg;
	}

	//  To launch URL
	public void launchUrl() {
		launchUrlOnBrowser();
	}

	// GroupA
	// click on ORG
	public void clickOnORG() {
		clickOnWebElement(HomePageOrgBarLocator);
	}

	// click on LOB
	public void clickOnLOB() {
		clickOnWebElement(HomePagelobTabLocator);
	}

	// click on Project Tab
	public void clickOnProject1() {
		clickOnWebElement(HomePageProjectTabLocator);
	}

	// clicks on User Drop-down
	public void clickOnUserDropdown() {
		clickOnWebElement(HomePageProfileDropDownLocator);
	}

	// To click on Admin settings
	public void clickOnAdminSettings() {
		clickOnWebElement(HomePageDropDownAdminSettingOptionLocator);
	}

	// Click on Profile
	public void clickOnProfile() {
		clickOnWebElement(HomePageDropDownProfileLocator);
	}

	//To logout
	public void logOut() {
		clickOnWebElement(HomePageDropDownLogOutBtnLocator);
	}


}

