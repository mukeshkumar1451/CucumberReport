package com.cognizant.pages;
 
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
 
public class CIQD_NewTemplate_Page extends CIQD_BasePage {
 
	private WebDriver driver;
 
	public CIQD_NewTemplate_Page(WebDriver driver) {
		super(driver);
		this.driver = driver;
	}
 
	// Click on project tab on CIQDDashboard Home screen
	private By ProjectTab = By.xpath("//label[@title='Project']");
	private By PRJDashboard = By.xpath("//*[text()='DashBoards']");
 
	// clicking on Create template Icon
	private By CreateTempBtn = By.xpath("//button[@title='Add Dashboard Template']");
 
	// Sending Template name
	private By TempName = By.xpath("//input[@name='newTemplateName']");
//	private By CrtButton = By.xpath("(//button[@type='button'])[14]");
	private By CrtButton = By.xpath("//button[text()='Create']");
	private By SuccessfulMSG = By.xpath("//div[@id='toast-container']");
	private By CreateTemplate = By.xpath("//*[text()='Create Template']");
 
	// for click on project tab
	public void clickOnProjectTab() { // clicking on project Tab
		clickOnWebElement(ProjectTab);
	}
 
	public void PRJDashboard() { // Clicking on Existing Dashboard
		clickOnWebElement(PRJDashboard);
	}
 
	public void CreateTempBtn() { // Creating template
		clickOnWebElement(CreateTempBtn);
	}
 
	public void TempName() {
		String TemplateName = properties.getProperty("TMPName");
		sendKeysOnWebElement(TempName, TemplateName);
		System.out.println("TemplateName entered : " + TemplateName);
	}
/*
	public void TempName() {
		waitUntilElementLocated(TempName, 2000);
		sendKeysOnWebElement(TempName, "TMPName");
	}
	*/	
	public void CrtButton() {
		clickOnWebElement(CrtButton);
	}
 
	public void TempSucess() {
		String success = driver.findElement(SuccessfulMSG).getText();
		System.out.println(success);
	}
	public String verifyCreateTemplate() {
		String createTemplate = getTextOnWebElement(CreateTemplate);
		return createTemplate;
	}
}