//Developed By Rohan Yerva and refactored by Rohit Bhavad

package com.cognizant.pages;
import static java.lang.invoke.MethodHandles.lookup;
import static org.slf4j.LoggerFactory.getLogger;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.slf4j.Logger;

public class CIQD_EditDashboardOnlyOptionsPage extends CIQD_BasePage {
	
	final static Logger log = getLogger(lookup().lookupClass());
	
	private WebDriver driver;

	private By projectDashboardName() {
	    String projectName = properties.getProperty("prjName");
	    return By.xpath("//div[@title='"+projectName+"']");
	}

	private By projectDashboardClick() {
	    String projectName = properties.getProperty("prjName");
	    return By.xpath("//div[@title='"+projectName+"']/following::div[3]/button[1]");
	}
	
	private By SVGCardTitle() {
		String chartTitle = properties.getProperty("ChartTitle");
	    return By.xpath("//div[contains(text(),'"+ chartTitle +"')]");
	}
	private By dashboardHeader() {
		String dashNameClick = properties.getProperty("dashboardName");
		return By.xpath("//button[text()='"+dashNameClick+"']");
	}


	//Element Xpath on Project Tab
	private By projectDropDown = By.xpath("//label[text()='Project']");
			
	//Mouse hover
	private By emptySpace = By.xpath("//header[@class='header-2']//div[@class='filler']");
	
	//Elements Xpath on Dashboard Screen
//	private By dashboardHeader = By.xpath("//button[@title='mydashboard2']");
	private By editOptionsButton= By.xpath("//button[text()='Edit Options']");
	private By saveDashboardButton = By.xpath("//clr-icon[@shape='floppy']");
	private By saveDashboardPopUp = By.xpath("//div[@aria-label='dashboard saved successfully']");
	private By refreshDashboardButton = By.xpath("//clr-icon[@shape='sync']");
	
	//Elements Xpath on Edit Dashboard Screen
	private By editDashboardHeader = By.xpath("//span[@class='is-editable']");
	private By titleInput = By.xpath("//input[@placeholder='title']");
	private By cancelIcon = By.xpath("//button[@title='Cancel']");
	
	//card chart
	private By innerPadding = By.xpath("//input[@placeholder='innerPadding']");
	private By cardColor = By.xpath("//input[@placeholder='cardColor']");
	private By textColor = By.xpath("//input[@placeholder='textColor']");
	private By caption = By.xpath("//input[@placeholder='caption']");
	
	
	//XPaths of Card Chart Image (SVG Web Element) on Dashboard Screen
	
	
	public CIQD_EditDashboardOnlyOptionsPage(WebDriver driver) {
		super(driver);
		this.driver = driver;
		}
	
	//This method is used to navigate to the Project Tab
	public void navigateToProject() {
		clickOnWebElement(projectDropDown);
		moveToElement(emptySpace);
	}
	
	//This method is used to verify if the existing dashboard is visible
	public boolean isExistingDashboardVisible() {
		moveToElement(projectDropDown);
		
		waitUntilElementVisible(projectDashboardName(),30);
		if(isElementPresent(projectDashboardName())) {
			return true;
		}
		else {
			return false;
		}
	}
	
	//this method clicks on existing dashboard from project tab dropdown
	public void dropdownExistingDashboardsClick() {
		waitUntilElementLocated(projectDropDown,3000);
		clickOnWebElement(projectDropDown);
		waitUntilElementLocated(projectDashboardName(),3000);
		clickOnWebElement(projectDashboardClick());
		moveToElement(emptySpace);
	}
	
	 //this method is used to verify if the page is navigated to the Dashboard Page 
	 public boolean isOnDashboardScreen() {
		    try {
	            return isElementVisible(dashboardHeader());
	        } catch (NullPointerException | NoSuchElementException e) {
	            return false;
	        }
	    }
	
	 //this method is used to verify if the page is navigated to the Edit Dashboard Page 
	 public boolean isOnEditDashboardScreen() {
		    try {
	            return isElementVisible(editDashboardHeader);
	        } catch (NullPointerException | NoSuchElementException e) {
	            return false;
	        }
	    }

	//this method is used to select the respective chart
	 public boolean selectChartToEdit(String chartTitle) {		 
		    // Check if the chart with the given title is already selected
		    // String selectedChartTitle = driver.findElement(SVGtitleXPath).getText();
		    String selectedChartTitle = driver.findElement(SVGCardTitle()).getText();
		    if (selectedChartTitle.equals(chartTitle)) {
		        System.out.println("Chart with title '" + chartTitle + "' is already selected.");
		        return true; // The chart is already selected
		    } else {
		        // Element not found, click on a chart item
		        clickOnWebElement(SVGCardTitle());
		        System.out.println("Clicked on the chart to select it.");
		        return false; // The chart was not selected before, but it is now
		    }
		}
	 
	 //this method is used to select the respective chart
	 public boolean isChartSelected(String chartTitle) {
	     String selectedChartTitle = driver.findElement(SVGCardTitle()).getText();  
	     if (selectedChartTitle.equals(chartTitle) && isElementVisible(editOptionsButton)) {
	         return true;
	     }	  
	     return false;
	 }

	 
	 //this method is used to modify card chart options
	 
	 public void modifyCardChartOptions(String title, String iPadding, String cColor, String tColor, String cCaption) { 
		 clearAndSendKeys(titleInput, title);
		 clearAndSendKeys(innerPadding, iPadding);
		 clearAndSendKeys(cardColor, cColor);
		 clearAndSendKeys(textColor, tColor);
		 clearAndSendKeys(caption, cCaption);
	 }
	 
	 
	 //this method is used to verify if the respective card chart options are modified successfully 
	 public boolean areCardChartOptionsModified(String title,String iPadding,String cColor,String tColor,String cCaption) {
			 
	        //Retrieve the modified chart options from the page and compare them with the expected values
		 String modifiedTitle = driver.findElement(titleInput).getAttribute("value");
	     String modifiediPadding = driver.findElement(innerPadding).getAttribute("value");
	     String modifiedcColor = driver.findElement(cardColor).getAttribute("value");
	     String modifiedtColor = driver.findElement(textColor).getAttribute("value");
	     String modifiedcCaption = driver.findElement(caption).getAttribute("value");
	 
	     return modifiedTitle.equals(title)
	       		&& modifiediPadding.equals(iPadding)
	       		&& modifiedcColor.equals(cColor)
	       		&& modifiedtColor.equals(tColor)
	       		&& modifiedcCaption.equals(cCaption);
	 }
	 
	 //this method is used to click on the save dashboard(floppy) button
	 public void clickSaveDashboard() {
		 //Click on the Save Dashboard button	  
		 waitUntilElementVisible(saveDashboardButton, 3000);   	
		 clickOnWebElement(saveDashboardButton);   	  	
	 }

	 //this method is used to click on the cancel button
	 public void clickCancelIcon() {
	     // Example: Click on the Cancel icon
	 	waitUntilElementVisible(cancelIcon, 3000);
	 	clickOnWebElement(cancelIcon);
	 }

	 //this method is used to verify if the cancel button is clicked
	 public boolean verifyCancelClicked() {
		if(isElementPresent(dashboardHeader())) {
			return true;
		}
		else if(isElementPresent(editDashboardHeader)){
			return false;
		}
		else {
			return false;
		}		
	}
	 
	 //this method is used to verify if the save dashboard(floppy) button is clicked
	 public boolean isSaveDashboardButtonClicked() {
			
		waitUntilElementVisible(saveDashboardPopUp, 10);
	    // Check if the success message element is present
	    return isElementVisible(saveDashboardPopUp);
		}
	 
	 //this method is used to click on the refresh button on dashboard page
	 public void clickRefreshDashboardBtn() {	 	
	     // Example: Click on the Refresh Dashboard button
	 	waitUntilElementVisible(refreshDashboardButton, 3000);  	
	 	clickOnWebElement(refreshDashboardButton);
	 }
 
	
	 //this method verifies if the card chart options are modified successfully
	public boolean verifyCardChartOptions(String expectedTitle) {	
		waitUntilElementVisible(SVGCardTitle(),3000);	
		String actualTitle = driver.findElement(SVGCardTitle()).getText();	
	    boolean titleMatch = actualTitle.equals(expectedTitle);   
	    return titleMatch ;

	}
}
